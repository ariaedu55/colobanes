<?php
// URL d'image via les variantes optimisées (_md/_sm) : les originaux peuvent avoir été supprimés
if (!function_exists('upload_image_url_from_src')) {
    require_once __DIR__ . '/includes/image_optimizer.php';
}
require_once __DIR__ . '/includes/session_user.php';
/**
 * Page stock produit — statistiques détaillées réservées aux administrateurs.
 * Les visiteurs sont redirigés vers la fiche produit publique.
 */

session_start_persistent();

$produit_id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
if ($produit_id <= 0) {
    header('Location: /');
    exit;
}

if (empty($_SESSION['admin_id']) || (int) $_SESSION['admin_id'] <= 0) {
    header('Location: /produit.php?id=' . $produit_id);
    exit;
}

require_once __DIR__ . '/conn/conn.php';
require_once __DIR__ . '/models/model_produits.php';
require_once __DIR__ . '/models/model_commandes.php';

$produit = get_produit_by_id($produit_id);
if (!$produit) {
    header('Location: /');
    exit;
}

// Vendeur : statistiques uniquement pour ses propres produits (rôles plateforme : accès global)
require_once __DIR__ . '/includes/admin_route_access.php';
$vf_stock = admin_vendeur_filter_id();
if ($vf_stock !== null && (int) ($produit['admin_id'] ?? 0) !== $vf_stock) {
    header('Location: /produit.php?id=' . $produit_id);
    exit;
}

$quantite_vendue = get_quantite_vendue_produit($produit_id);
$stock_actuel = (int) ($produit['stock'] ?? 0);
$nombre_total = $stock_actuel + $quantite_vendue;
$stock_restant = $nombre_total - $quantite_vendue;

$prix_produit = (float) ($produit['prix'] ?? 0);
if (!empty($produit['prix_promotion']) && (float) $produit['prix_promotion'] < $prix_produit) {
    $prix_produit = (float) $produit['prix_promotion'];
}
$valeur_stock_actuel = $stock_actuel * $prix_produit;
$valeur_ventes = $quantite_vendue * $prix_produit;

require_once __DIR__ . '/includes/site_url.php';
require_once __DIR__ . '/includes/site_brand.php';
$base = get_site_base_url();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <?php include __DIR__ . '/includes/favicon.php'; ?>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stock - <?php echo htmlspecialchars($produit['nom']); ?> — <?php echo htmlspecialchars(SITE_BRAND_NAME, ENT_QUOTES, 'UTF-8'); ?></title>    <?php require_once __DIR__ . '/includes/ui_font_awesome.php'; ?>
<style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
            background: linear-gradient(135deg, #f5f7fa 0%, #e4e8ec 100%);
            min-height: 100vh;
            padding: 24px;
            color: #333;
        }
        .container {
            max-width: 480px;
            margin: 0 auto;
        }
        .card {
            background: #fff;
            border-radius: 16px;
            padding: 24px;
            margin-bottom: 16px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.08);
            border: 1px solid #e5e7eb;
        }
        .card-header {
            display: flex;
            align-items: center;
            gap: 16px;
            margin-bottom: 24px;
            padding-bottom: 20px;
            border-bottom: 2px solid #3564a6;
        }
        .card-header img {
            width: 72px;
            height: 72px;
            object-fit: cover;
            border-radius: 12px;
            border: 2px solid #e5e7eb;
        }
        .card-header h1 {
            font-size: 18px;
            color: #1f2937;
            flex: 1;
        }
        .stock-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 12px;
        }
        .stock-item {
            background: #f8fafc;
            border-radius: 12px;
            padding: 16px;
            text-align: center;
            border: 1px solid #e2e8f0;
        }
        .stock-item.full {
            grid-column: 1 / -1;
        }
        .stock-item .label {
            font-size: 11px;
            color: #64748b;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 6px;
        }
        .stock-item .value {
            font-size: 24px;
            font-weight: 700;
        }
        .stock-item.total .value { color: #1e40af; }
        .stock-item.vendu .value { color: #c2410c; }
        .stock-item.restant .value { color: #15803d; }
        .stock-item .detail {
            font-size: 11px;
            color: #94a3b8;
            margin-top: 4px;
        }
        .brand {
            text-align: center;
            margin-top: 24px;
            font-size: 14px;
            color: #64748b;
            font-weight: 600;
        }
        .brand a { color: #3564a6; text-decoration: none; }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <div class="card-header">
                <img src="<?php echo htmlspecialchars(upload_image_url_from_src((string) ($produit['image_principale'] ?? ''), 'md'), ENT_QUOTES, 'UTF-8'); ?>" 
                     alt="" onerror="this.src='/image/produit1.jpg'">
                <h1><?php echo htmlspecialchars($produit['nom']); ?></h1>
            </div>

            <div class="stock-grid">
                <div class="stock-item total full">
                    <div class="label">Nombre total (initial + entrées)</div>
                    <div class="value"><?php echo $nombre_total; ?></div>
                    <div class="detail">Stock initial + entrées</div>
                </div>
                <div class="stock-item vendu">
                    <div class="label">Quantité vendue</div>
                    <div class="value"><?php echo $quantite_vendue; ?></div>
                </div>
                <div class="stock-item restant">
                    <div class="label">Stock restant</div>
                    <div class="value"><?php echo $stock_restant; ?></div>
                    <div class="detail">Total − Vendu</div>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="stock-item total" style="margin-bottom: 12px;">
                <div class="label">Valeur du stock actuel</div>
                <div class="value" style="font-size: 20px;"><?php echo number_format($valeur_stock_actuel, 0, ',', ' '); ?> FCFA</div>
                <div class="detail"><?php echo $stock_actuel; ?> × <?php echo number_format($prix_produit, 0, ',', ' '); ?> FCFA</div>
            </div>
            <div class="stock-item vendu">
                <div class="label">Chiffre d'affaires (ventes)</div>
                <div class="value" style="font-size: 20px;"><?php echo number_format($valeur_ventes, 0, ',', ' '); ?> FCFA</div>
                <div class="detail"><?php echo $quantite_vendue; ?> vendu(s)</div>
            </div>
        </div>

        <p class="brand"><?php echo htmlspecialchars(SITE_BRAND_NAME, ENT_QUOTES, 'UTF-8'); ?> — marketplace Sénégal</p>
    </div>
</body>
</html>
