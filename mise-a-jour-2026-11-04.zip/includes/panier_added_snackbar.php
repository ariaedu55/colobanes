<?php
/**
 * Snackbar léger « Ajouté au panier » (apparaît puis disparaît).
 */

if (!function_exists('panier_added_snackbar_mark')) {
    function panier_added_snackbar_mark(): void
    {
        if (session_status() !== PHP_SESSION_ACTIVE) {
            if (!function_exists('session_start_persistent')) {
                require_once __DIR__ . '/session_user.php';
            }
            session_start_persistent();
        }
        $_SESSION['panier_added_snackbar'] = 1;
    }
}

if (!function_exists('panier_added_snackbar_should_show')) {
    function panier_added_snackbar_should_show(): bool
    {
        if (session_status() !== PHP_SESSION_ACTIVE) {
            if (!function_exists('session_start_persistent')) {
                require_once __DIR__ . '/session_user.php';
            }
            session_start_persistent();
        }
        if (empty($_SESSION['panier_added_snackbar'])) {
            return false;
        }
        unset($_SESSION['panier_added_snackbar']);

        return true;
    }
}

if (!function_exists('panier_added_snackbar_render')) {
    function panier_added_snackbar_render(): void
    {
        static $rendered = false;
        if ($rendered) {
            return;
        }
        $rendered = true;

        if (!panier_added_snackbar_should_show()) {
            return;
        }

        if (!function_exists('asset_version_query')) {
            require_once __DIR__ . '/asset_version.php';
        }
        if (!function_exists('app_url')) {
            require_once __DIR__ . '/app_base.php';
        }

        $v = asset_version_query();
        echo '<link rel="stylesheet" href="' . htmlspecialchars(app_url('/css/panier-added-snackbar.css' . $v), ENT_QUOTES, 'UTF-8') . '">' . "\n";
        echo '<script src="' . htmlspecialchars(app_url('/js/panier-added-snackbar.js' . $v), ENT_QUOTES, 'UTF-8') . '" defer></script>' . "\n";
    }
}
