<?php
/**
 * Charge les clés API de l'assistant depuis un fichier HORS de la racine web.
 * Aucune clé n'est lue depuis config/ (dossier éventuellement exposé en cas de mauvaise config Apache).
 *
 * Fichier attendu : assistant_keys.php retournant un tableau.
 * Emplacements essayés (le premier lisible gagne) :
 *   1) Variable d'environnement COLOBANES_ASSISTANT_KEYS (chemin absolu)
 *   2) /home/colobanes/secrets/assistant_keys.php          (production)
 *   3) {parent de htdocs}/secrets/assistant_keys.php       (XAMPP local)
 *   4) Variables d'environnement GEMINI_API_KEY, OPENROUTER_API_KEY, CLOUDFLARE_*
 */

if (!function_exists('assistant_keys_load')) {
    /**
     * @return array{gemini_api_key:string,openrouter_api_key:string,cloudflare_account_id:string,cloudflare_api_token:string,source:string}
     */
    function assistant_keys_load(): array
    {
        static $keys = null;
        if ($keys !== null) {
            return $keys;
        }

        $empty = [
            'gemini_api_key' => '',
            'gemini_project_id' => '',
            'openrouter_api_key' => '',
            'cloudflare_account_id' => '',
            'cloudflare_api_token' => '',
            'source' => 'none',
        ];

        $candidates = [];
        $env_path = trim((string) getenv('COLOBANES_ASSISTANT_KEYS'));
        if ($env_path !== '') {
            $candidates[] = $env_path;
        }
        $candidates[] = '/home/colobanes/secrets/assistant_keys.php';
        $doc = (string) ($_SERVER['DOCUMENT_ROOT'] ?? '');
        if ($doc !== '') {
            $parent = dirname(rtrim($doc, '/'));
            if ($parent !== '' && $parent !== '/' && $parent !== '.') {
                $candidates[] = $parent . '/secrets/assistant_keys.php';
            }
        }
        /* includes/assistant → xamppfiles/secrets (4 niveaux) */
        $candidates[] = dirname(__DIR__, 3) . '/../secrets/assistant_keys.php';
        $candidates[] = dirname(__DIR__, 4) . '/secrets/assistant_keys.php';

        foreach ($candidates as $path) {
            $path = str_replace('\\', '/', (string) $path);
            if ($path === '' || !is_readable($path)) {
                continue;
            }
            /* Refus si le fichier est sous la racine web */
            $real = realpath($path);
            $web = $doc !== '' ? realpath($doc) : false;
            if ($real && $web && strpos($real, rtrim($web, '/') . '/') === 0) {
                error_log('[assistant] Fichier de clés ignoré (dans le web root) : ' . basename($real));
                continue;
            }
            $loaded = include $path;
            if (!is_array($loaded)) {
                continue;
            }
            $keys = [
                'gemini_api_key' => trim((string) ($loaded['gemini_api_key'] ?? '')),
                'gemini_project_id' => trim((string) ($loaded['gemini_project_id'] ?? '')),
                'openrouter_api_key' => trim((string) ($loaded['openrouter_api_key'] ?? '')),
                'cloudflare_account_id' => trim((string) ($loaded['cloudflare_account_id'] ?? '')),
                'cloudflare_api_token' => trim((string) ($loaded['cloudflare_api_token'] ?? '')),
                'source' => $real ?: $path,
            ];
            return $keys;
        }

        $from_env = [
            'gemini_api_key' => trim((string) getenv('GEMINI_API_KEY')),
            'openrouter_api_key' => trim((string) getenv('OPENROUTER_API_KEY')),
            'cloudflare_account_id' => trim((string) getenv('CLOUDFLARE_ACCOUNT_ID')),
            'cloudflare_api_token' => trim((string) getenv('CLOUDFLARE_API_TOKEN')),
            'source' => 'env',
        ];
        if ($from_env['gemini_api_key'] !== ''
            || $from_env['openrouter_api_key'] !== ''
            || $from_env['cloudflare_api_token'] !== '') {
            $keys = $from_env;
            return $keys;
        }

        $keys = $empty;
        return $keys;
    }
}

if (!function_exists('assistant_keys_public_status')) {
    /**
     * État des clés pour l'admin — jamais la valeur, seulement configuré / manquant.
     *
     * @return array<string, array{configured:bool,hint:string}>
     */
    function assistant_keys_public_status(): array
    {
        $k = assistant_keys_load();
        $src = (string) ($k['source'] ?? 'none');
        $src_label = $src === 'none' ? 'aucun fichier' : ($src === 'env' ? 'variables d\'environnement' : 'fichier hors web');
        return [
            'gemini' => [
                'configured' => $k['gemini_api_key'] !== '',
                'hint' => $src_label,
            ],
            'openrouter' => [
                'configured' => $k['openrouter_api_key'] !== '',
                'hint' => $src_label,
            ],
            'cloudflare' => [
                'configured' => $k['cloudflare_api_token'] !== '',
                'hint' => $src_label,
            ],
        ];
    }
}
