<?php
/**
 * Compression et variantes WebP des images uploadées (PHP 8.4 + extension GD).
 *
 * À l'upload : redimensionnement + encodage WebP + variantes _md (800px) et _sm (400px).
 * À l'affichage : upload_image_url() pour servir la variante adaptée.
 */

require_once __DIR__ . '/upload_image_limits.php';

if (!defined('IMAGE_OPTIMIZER_MAX_WIDTH')) {
    define('IMAGE_OPTIMIZER_MAX_WIDTH', 1920);
}
if (!defined('IMAGE_OPTIMIZER_MD_WIDTH')) {
    define('IMAGE_OPTIMIZER_MD_WIDTH', 800);
}
if (!defined('IMAGE_OPTIMIZER_SM_WIDTH')) {
    define('IMAGE_OPTIMIZER_SM_WIDTH', 400);
}
if (!defined('IMAGE_OPTIMIZER_WEBP_QUALITY')) {
    define('IMAGE_OPTIMIZER_WEBP_QUALITY', 82);
}

/**
 * @return list<string>
 */
function image_optimizer_allowed_mimes() {
    return ['image/jpeg', 'image/png', 'image/gif', 'image/webp'];
}

function image_optimizer_gd_available() {
    return extension_loaded('gd') && function_exists('imagecreatetruecolor');
}

function image_optimizer_webp_available() {
    return image_optimizer_gd_available() && function_exists('imagewebp');
}

/**
 * @return string
 */
function image_optimizer_detect_mime($path) {
    if (!is_file($path)) {
        return '';
    }
    if (function_exists('finfo_open')) {
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        if ($finfo) {
            $mime = (string) finfo_file($finfo, $path);
            finfo_close($finfo);
            if ($mime !== '') {
                return $mime;
            }
        }
    }
    $info = @getimagesize($path);
    if (is_array($info) && !empty($info['mime'])) {
        return (string) $info['mime'];
    }
    return '';
}

/**
 * @return \GdImage|false
 */
function image_optimizer_load($path) {
    if (!image_optimizer_gd_available() || !is_file($path)) {
        return false;
    }
    $blob = @file_get_contents($path);
    if ($blob === false || $blob === '') {
        return false;
    }
    $img = @imagecreatefromstring($blob);
    if ($img === false) {
        return false;
    }
    if (function_exists('imageresolution')) {
        @imageresolution($img, 72, 72);
    }
    return $img;
}

/**
 * @param \GdImage $src
 * @return \GdImage|false
 */
function image_optimizer_resize($src, $max_width) {
    $src_w = imagesx($src);
    $src_h = imagesy($src);
    if ($src_w <= 0 || $src_h <= 0) {
        return false;
    }
    $max_width = max(1, (int) $max_width);
    if ($src_w <= $max_width) {
        $dst_w = $src_w;
        $dst_h = $src_h;
    } else {
        $dst_w = $max_width;
        $dst_h = (int) round($src_h * ($max_width / $src_w));
    }
    $dst = imagecreatetruecolor($dst_w, $dst_h);
    if ($dst === false) {
        return false;
    }
    imagealphablending($dst, false);
    imagesavealpha($dst, true);
    $transparent = imagecolorallocatealpha($dst, 0, 0, 0, 127);
    if ($transparent !== false) {
        imagefill($dst, 0, 0, $transparent);
    }
    imagecopyresampled($dst, $src, 0, 0, 0, 0, $dst_w, $dst_h, $src_w, $src_h);
    return $dst;
}

/**
 * @param \GdImage $img
 */
function image_optimizer_save_webp($img, $dest_path, $quality = IMAGE_OPTIMIZER_WEBP_QUALITY) {
    if (!image_optimizer_webp_available()) {
        return false;
    }
    $dir = dirname($dest_path);
    if (!is_dir($dir) && !mkdir($dir, 0755, true) && !is_dir($dir)) {
        return false;
    }
    return imagewebp($img, $dest_path, max(1, min(100, (int) $quality)));
}

/**
 * Traite un fichier temporaire d'upload : original WebP + variantes _md et _sm.
 *
 * @return array{success:bool, relative_path?:string, filename?:string, message?:string, bytes_before?:int, bytes_after?:int}
 */
/**
 * Résout un chemin BDD vers le fichier réel (ex. foo.png → foo.webp si converti).
 */
function image_optimizer_resolve_relative_path($relative_path) {
    $relative_path = trim(str_replace('\\', '/', (string) $relative_path), '/');
    if ($relative_path === '') {
        return '';
    }
    $upload_root = dirname(__DIR__) . '/upload/';
    if (is_file($upload_root . $relative_path)) {
        return $relative_path;
    }
    $dir = dirname($relative_path);
    $stem = pathinfo($relative_path, PATHINFO_FILENAME);
    if ($stem === '') {
        return $relative_path;
    }
    $webp_rel = ($dir === '.' || $dir === '') ? $stem . '.webp' : $dir . '/' . $stem . '.webp';
    if (is_file($upload_root . $webp_rel)) {
        return $webp_rel;
    }
    return $relative_path;
}

/**
 * Si un .webp existe pour le même nom de base, retourne le chemin .webp.
 */
function image_optimizer_normalize_db_path($relative_path) {
    $resolved = image_optimizer_resolve_relative_path($relative_path);
    $ext = strtolower(pathinfo($resolved, PATHINFO_EXTENSION));
    if ($ext === 'webp') {
        return $resolved;
    }
    $upload_root = dirname(__DIR__) . '/upload/';
    $dir = dirname($resolved);
    $stem = pathinfo($resolved, PATHINFO_FILENAME);
    if ($stem === '') {
        return $resolved;
    }
    $webp_rel = ($dir === '.' || $dir === '') ? $stem . '.webp' : $dir . '/' . $stem . '.webp';
    if (is_file($upload_root . $webp_rel)) {
        return $webp_rel;
    }
    return $resolved;
}

function image_optimizer_process_tmp($tmp_path, $dest_dir, $relative_subdir, $name_prefix, $fixed_stem = null) {
    if (!is_uploaded_file($tmp_path) && !is_file($tmp_path)) {
        return ['success' => false, 'message' => 'Fichier source introuvable.'];
    }

    $bytes_before = (int) (@filesize($tmp_path) ?: 0);
    if ($bytes_before <= 0) {
        return ['success' => false, 'message' => 'Fichier vide.'];
    }
    if ($bytes_before > UPLOAD_MAX_IMAGE_BYTES) {
        return ['success' => false, 'message' => 'Image trop volumineuse.'];
    }

    $mime = image_optimizer_detect_mime($tmp_path);
    if ($mime === '' || !in_array($mime, image_optimizer_allowed_mimes(), true)) {
        return ['success' => false, 'message' => 'Format d\'image non supporté.'];
    }

    if (!is_dir($dest_dir) && !mkdir($dest_dir, 0755, true) && !is_dir($dest_dir)) {
        return ['success' => false, 'message' => 'Impossible de créer le dossier d\'upload.'];
    }

    if (is_string($fixed_stem) && $fixed_stem !== '') {
        $safe_stem = preg_replace('/[^a-zA-Z0-9._-]/', '_', $fixed_stem);
        $base_name = ($safe_stem !== '') ? $safe_stem : ($name_prefix . bin2hex(random_bytes(8)));
    } else {
        $base_name = $name_prefix . bin2hex(random_bytes(8));
    }
    $filename = $base_name . '.webp';
    $dest_path = rtrim($dest_dir, '/\\') . DIRECTORY_SEPARATOR . $filename;

    if (!image_optimizer_webp_available()) {
        return image_optimizer_fallback_move($tmp_path, $dest_dir, $relative_subdir, $mime, $name_prefix, $bytes_before);
    }

    $src = image_optimizer_load($tmp_path);
    if ($src === false) {
        return image_optimizer_fallback_move($tmp_path, $dest_dir, $relative_subdir, $mime, $name_prefix, $bytes_before);
    }

    $variants = [
        ['suffix' => '', 'width' => IMAGE_OPTIMIZER_MAX_WIDTH],
        ['suffix' => '_md', 'width' => IMAGE_OPTIMIZER_MD_WIDTH],
        ['suffix' => '_sm', 'width' => IMAGE_OPTIMIZER_SM_WIDTH],
    ];

    $saved = [];
    foreach ($variants as $variant) {
        $resized = image_optimizer_resize($src, (int) $variant['width']);
        if ($resized === false) {
            continue;
        }
        $variant_file = $base_name . $variant['suffix'] . '.webp';
        $variant_path = rtrim($dest_dir, '/\\') . DIRECTORY_SEPARATOR . $variant_file;
        if (image_optimizer_save_webp($resized, $variant_path)) {
            $saved[] = $variant_file;
        }
        imagedestroy($resized);
    }
    imagedestroy($src);

    if (empty($saved)) {
        return ['success' => false, 'message' => 'Échec de la compression WebP.'];
    }

    $bytes_after = 0;
    foreach ($saved as $saved_file) {
        $bytes_after += (int) (@filesize(rtrim($dest_dir, '/\\') . DIRECTORY_SEPARATOR . $saved_file) ?: 0);
    }

    $relative_subdir = trim(str_replace('\\', '/', $relative_subdir), '/');
    $relative_path = ($relative_subdir !== '' ? $relative_subdir . '/' : '') . $filename;

    return [
        'success' => true,
        'relative_path' => $relative_path,
        'filename' => $filename,
        'message' => '',
        'bytes_before' => $bytes_before,
        'bytes_after' => $bytes_after,
    ];
}

/**
 * Secours si GD/WebP indisponible : enregistre le fichier original.
 *
 * @return array{success:bool, relative_path?:string, filename?:string, message?:string, bytes_before?:int, bytes_after?:int}
 */
function image_optimizer_fallback_move($tmp_path, $dest_dir, $relative_subdir, $mime, $name_prefix, $bytes_before) {
    $ext_map = [
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/gif' => 'gif',
        'image/webp' => 'webp',
    ];
    $ext = $ext_map[$mime] ?? 'jpg';
    $filename = $name_prefix . bin2hex(random_bytes(8)) . '.' . $ext;
    $dest_path = rtrim($dest_dir, '/\\') . DIRECTORY_SEPARATOR . $filename;

    $moved = is_uploaded_file($tmp_path)
        ? move_uploaded_file($tmp_path, $dest_path)
        : @rename($tmp_path, $dest_path);

    if (!$moved) {
        return ['success' => false, 'message' => 'Impossible d\'enregistrer l\'image.'];
    }

    $relative_subdir = trim(str_replace('\\', '/', $relative_subdir), '/');
    return [
        'success' => true,
        'relative_path' => ($relative_subdir !== '' ? $relative_subdir . '/' : '') . $filename,
        'filename' => $filename,
        'message' => '',
        'bytes_before' => $bytes_before,
        'bytes_after' => (int) (@filesize($dest_path) ?: $bytes_before),
    ];
}

/**
 * Enregistre et optimise un fichier issu de $_FILES (champ unitaire).
 *
 * @param array<string,mixed> $file_info
 * @return array{success:bool, relative_path?:string, filename?:string, message?:string}
 */
function upload_optimize_image_file(array $file_info, $dest_dir, $relative_subdir, $name_prefix) {
    if (!isset($file_info['error']) || (int) $file_info['error'] !== UPLOAD_ERR_OK) {
        return ['success' => false, 'message' => 'Upload invalide.'];
    }
    $tmp = (string) ($file_info['tmp_name'] ?? '');
    if ($tmp === '' || !is_uploaded_file($tmp)) {
        return ['success' => false, 'message' => 'Fichier temporaire manquant.'];
    }
    return image_optimizer_process_tmp($tmp, $dest_dir, $relative_subdir, $name_prefix);
}

/**
 * URL publique d'une image uploadée avec variante (md catalogue, sm vignette, original fiche).
 *
 * @param string $relative_path Chemin relatif sous upload/ (ex. produits/xxx.webp)
 * @param string $variant original|md|sm
 */
/**
 * Accepte un chemin relatif (produits/x.webp) ou une URL /upload/… déjà construite.
 *
 * @param string $src
 * @param string $variant original|md|sm
 */
function upload_image_url_from_src($src, $variant = 'md') {
    $src = trim(str_replace('\\', '/', (string) $src), '/');
    if ($src === '') {
        return upload_image_url('', $variant);
    }
    if (str_starts_with($src, 'upload/')) {
        $src = substr($src, 7);
    }
    return upload_image_url($src, $variant);
}

if (!function_exists('upload_image_public_path')) {
    /**
     * Préfixe un chemin web (/upload/…, /image/…) avec le base path local si besoin.
     */
    function upload_image_public_path(string $web_path): string
    {
        if (!function_exists('app_url')) {
            require_once __DIR__ . '/app_base.php';
        }

        $web_path = '/' . ltrim(str_replace('\\', '/', $web_path), '/');

        return app_url($web_path);
    }
}

if (!function_exists('upload_image_fallback_url')) {
    /**
     * Image de remplacement si le fichier upload/ est absent (local sans médias importés).
     */
    function upload_image_fallback_url(): string
    {
        static $cached = null;
        if ($cached !== null) {
            return $cached;
        }

        $candidates = ['produit1.jpg', 'produit2.jpg', 'produit3.jpg'];
        $image_root = dirname(__DIR__) . '/image/';
        foreach ($candidates as $file) {
            if (is_file($image_root . $file)) {
                $cached = upload_image_public_path('/image/' . $file);
                return $cached;
            }
        }

        $cached = upload_image_public_path('/image/logo_market.png');
        return $cached;
    }
}

function upload_image_local_exists($relative_path) {
    $relative_path = trim(str_replace('\\', '/', (string) $relative_path), '/');
    if ($relative_path === '') {
        return false;
    }
    $relative_path = image_optimizer_resolve_relative_path($relative_path);
    $path = dirname(__DIR__) . '/upload/' . $relative_path;

    return is_file($path) && filesize($path) > 100;
}

function upload_image_url($relative_path, $variant = 'md') {
    $relative_path = trim(str_replace('\\', '/', (string) $relative_path), '/');
    if ($relative_path === '') {
        return upload_image_fallback_url();
    }

    $relative_path = image_optimizer_resolve_relative_path($relative_path);
    $upload_root = dirname(__DIR__) . '/upload/';

    $variant = strtolower(trim((string) $variant));
    if ($variant === '' || $variant === 'original') {
        if (is_file($upload_root . $relative_path)) {
            return upload_image_public_path('/upload/' . $relative_path);
        }

        return upload_image_fallback_url();
    }
    if (!in_array($variant, ['md', 'sm'], true)) {
        $variant = 'md';
    }

    $variant_rel = image_optimizer_variant_relative_path($relative_path, $variant);
    if ($variant_rel !== '' && is_file($upload_root . $variant_rel)) {
        return upload_image_public_path('/upload/' . $variant_rel);
    }
    if (is_file($upload_root . $relative_path)) {
        return upload_image_public_path('/upload/' . $relative_path);
    }

    return upload_image_fallback_url();
}

/**
 * @return string
 */
function image_optimizer_variant_relative_path($relative_path, $variant) {
    $relative_path = trim(str_replace('\\', '/', (string) $relative_path), '/');
    if ($relative_path === '') {
        return '';
    }
    $dir = dirname($relative_path);
    $base = pathinfo($relative_path, PATHINFO_FILENAME);
    $variant_name = $base . '_' . $variant . '.webp';
    if ($dir === '.' || $dir === '') {
        return $variant_name;
    }
    return $dir . '/' . $variant_name;
}

/**
 * Supprime une image et ses variantes _md / _sm.
 */
function image_optimizer_delete_with_variants($relative_path) {
    $relative_path = trim(str_replace('\\', '/', (string) $relative_path), '/');
    if ($relative_path === '') {
        return;
    }
    $upload_root = dirname(__DIR__) . '/upload/';
    $paths = [$relative_path];
    foreach (['md', 'sm'] as $variant) {
        $variant_rel = image_optimizer_variant_relative_path($relative_path, $variant);
        if ($variant_rel !== '') {
            $paths[] = $variant_rel;
        }
    }
    foreach (array_unique($paths) as $rel) {
        $abs = $upload_root . $rel;
        if (is_file($abs)) {
            @unlink($abs);
        }
    }
}
