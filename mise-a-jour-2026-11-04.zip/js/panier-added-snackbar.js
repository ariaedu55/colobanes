(function () {
    'use strict';

    function showPanierAddedSnack() {
        var host = document.createElement('div');
        host.className = 'panier-added-snack-host';
        host.setAttribute('role', 'status');
        host.setAttribute('aria-live', 'polite');

        var snack = document.createElement('div');
        snack.className = 'panier-added-snack';
        snack.innerHTML =
            '<span class="panier-added-snack__icon" aria-hidden="true"><i class="fas fa-check"></i></span>' +
            '<span>Ajouté au panier</span>';

        host.appendChild(snack);
        document.body.appendChild(host);

        requestAnimationFrame(function () {
            requestAnimationFrame(function () {
                snack.classList.add('is-visible');
            });
        });

        window.setTimeout(function () {
            snack.classList.remove('is-visible');
            snack.classList.add('is-leaving');
        }, 2000);

        window.setTimeout(function () {
            if (host.parentNode) {
                host.parentNode.removeChild(host);
            }
        }, 2350);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', showPanierAddedSnack);
    } else {
        showPanierAddedSnack();
    }
})();
