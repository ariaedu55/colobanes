<?php
require_once __DIR__ . '/includes/session_user.php';
session_start_persistent();

require_once __DIR__ . '/includes/produit_boutique_line.php';

// Inclusion du fichier de connexion à la BDD

// Récupérez l'ID du commerçant à partir de la session
// Récupérez l'ID de l'utilisateur depuis la variable de session
if (file_exists(__DIR__ . '/controllers/controller_commerce_users.php')) {
    require_once __DIR__ . '/controllers/controller_commerce_users.php';
}

// Meta SEO
require_once __DIR__ . '/includes/site_url.php';
require_once __DIR__ . '/includes/site_brand.php';
$base = get_site_base_url();
$seo_title = site_brand_seo_title_default();
$seo_description = site_brand_seo_description_default();
$seo_keywords = site_brand_seo_keywords_default();
$seo_canonical = $base . '/';
require_once __DIR__ . '/includes/seo_structured_data.php';
$seo_json_ld_blocks = [
    seo_structured_data_homepage_graph(),
];
?>




<!DOCTYPE html>
<html lang="fr" class="aos-not-ready">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php
    require_once __DIR__ . '/includes/asset_version.php';
    require_once __DIR__ . '/includes/app_base.php';
    require_once __DIR__ . '/includes/site_perf_head.php';
    ?>
    <?php include __DIR__ . '/includes/pwa_meta.php'; ?>
    <?php include __DIR__ . '/includes/seo_meta.php'; ?>
    <?php site_perf_emit_resource_hints(); ?>
    <?php
    site_perf_preload_stylesheet(app_url('/css/variables.css' . asset_version_query()));
    site_perf_preload_stylesheet(app_url('/css/style.css' . asset_version_query()));
    ?>
    <link rel="stylesheet" href="<?php echo htmlspecialchars(app_url('/css/variables.css' . asset_version_query()), ENT_QUOTES, 'UTF-8'); ?>">
    <link rel="stylesheet" href="<?php echo htmlspecialchars(app_url('/css/style.css' . asset_version_query()), ENT_QUOTES, 'UTF-8'); ?>">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" crossorigin="anonymous">
    <?php site_perf_stylesheet_deferred('https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css'); ?>
    <?php site_perf_stylesheet_deferred('https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css'); ?>
    <style>
        /* AOS masque [data-aos] dans sa feuille CSS avant que le JS n’ajoute .aos-animate — affichage immédiat jusqu’à init */
        html.aos-not-ready [data-aos] {
            opacity: 1 !important;
            transform: none !important;
            filter: none !important;
            pointer-events: auto !important;
        }
    </style>
    <?php
    site_perf_stylesheet_deferred(app_url('/css/owl.carousel.min.css' . asset_version_query()));
    site_perf_stylesheet_deferred(app_url('/css/animate.min.css' . asset_version_query()));
    ?>
    <link rel="stylesheet" href="<?php echo htmlspecialchars(app_url('/css/a_style.css' . asset_version_query()), ENT_QUOTES, 'UTF-8'); ?>">
    <link rel="stylesheet" href="<?php echo htmlspecialchars(app_url('/css/product-cards.css' . asset_version_query()), ENT_QUOTES, 'UTF-8'); ?>">
    <link rel="stylesheet" href="<?php echo htmlspecialchars(app_url('/css/boutiques-marketplace.css' . asset_version_query()), ENT_QUOTES, 'UTF-8'); ?>">
    <link rel="stylesheet" href="<?php echo htmlspecialchars(app_url('/css/mp-shops.css' . asset_version_query()), ENT_QUOTES, 'UTF-8'); ?>">
    <link rel="stylesheet" href="<?php echo htmlspecialchars(app_url('/css/mp-hero-slider.css' . asset_version_query()), ENT_QUOTES, 'UTF-8'); ?>">
    <style>
        /* Bannière vitrine - Design site vitrine professionnel */
        .vitrine-hero {
            position: relative;
            padding: 60px 24px 50px;
            overflow: hidden;
        }

        .vitrine-hero-bg {
            position: absolute;
            inset: 0;
            background: var(--fond-page);
            z-index: 0;
        }

        .vitrine-hero-bg::before {
            content: '';
            position: absolute;
            inset: 0;
            background-image: url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%233564a6' fill-opacity='0.03'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E");
            opacity: 0.6;
        }

        .vitrine-hero-content {
            position: relative;
            z-index: 1;
            max-width: 900px;
            margin: 0 auto;
            text-align: center;
        }

        .vitrine-hero-title {
            font-size: clamp(24px, 4vw, 36px);
            font-weight: 700;
            color: var(--couleur-dominante);
            letter-spacing: 2px;
            text-transform: uppercase;
            margin: 0 0 20px;
            font-family: var(--font-titres);
        }

        .vitrine-hero-desc {
            font-size: clamp(14px, 1.8vw, 16px);
            line-height: 1.7;
            color: var(--gris-fonce);
            margin: 0 0 40px;
            max-width: 700px;
            margin-left: auto;
            margin-right: auto;
        }

        .vitrine-services-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 12px;
            max-width: 900px;
            margin: 0 auto;
        }

        .vitrine-service-block {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: 14px;
            padding: 28px 20px;
            background: var(--couleur-dominante);
            color: var(--texte-clair);
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.3s ease;
            min-height: 140px;
        }

        .vitrine-service-block:hover {
            background: var(--couleur-dominante-hover);
            transform: translateY(-4px);
            box-shadow: var(--ombre-gourmande);
        }

        .vitrine-service-icon {
            font-size: 36px;
            opacity: 0.95;
        }

        .vitrine-service-label {
            font-size: 13px;
            font-weight: 700;
            letter-spacing: 1px;
            text-transform: uppercase;
        }

        @media (max-width: 768px) {
            .vitrine-hero {
                padding: 40px 16px 36px;
            }

            .vitrine-services-grid {
                grid-template-columns: repeat(2, 1fr);
                gap: 10px;
            }

            .vitrine-service-block {
                padding: 24px 16px;
                min-height: 120px;
            }

            .vitrine-service-icon {
                font-size: 28px;
            }

            .vitrine-service-label {
                font-size: 11px;
            }
        }

        @media (max-width: 400px) {
            .vitrine-services-grid {
                grid-template-columns: 1fr;
            }
        }

        /* Nouveaux produits et Produits populaires : flex-wrap, Owl désactivé, 6 produits max */
        .carousel-produits-outer {
            position: relative;
            width: 100%;
        }

        .carousel-produits-outer .carousel1.carousel1-flex-mode {
            display: flex !important;
            flex-wrap: wrap;
            justify-content: space-around;
            align-items: flex-start;
            gap: 15px;
            padding: 15px;
        }

        .carousel-produits-outer .carousel1.carousel1-flex-mode .carousel {
            width: 320px;
            min-width: 170px;
            max-width: 320px;
            flex: 0 0 320px;
        }

        .carousel-produits-outer .carousel1.carousel1-flex-mode .carousel:nth-child(n+7) {
            display: none !important;
        }

        @media (max-width: 650px) {
            .carousel-produits-outer .carousel1.carousel1-flex-mode {
                gap: 12px;
                padding: 12px;
            }
        }

        @media (max-width: 400px) {
            .carousel-produits-outer .carousel1.carousel1-flex-mode {
                gap: 10px;
                padding: 10px;
            }
        }

        /* Carrousel des catégories */
        .marques-section {
            padding: 20px 0 20px;
            background: var(--blanc);
            border-top: 1px solid var(--glass-border);
        }

        .marques-container {
            position: relative;
            max-width: 1280px;
            margin: 0 auto;
            padding: 0 60px;
        }

        .marques-nav {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            width: 50px;
            height: 50px;
            border-radius: 50%;
            border: 1px solid var(--gris-clair);
            background: var(--blanc);
            color: var(--couleur-dominante);
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 10;
            transition: all 0.25s ease;
            box-shadow: var(--ombre-douce);
        }

        .marques-nav:hover {
            background: var(--couleur-dominante);
            color: var(--blanc);
            border-color: var(--couleur-dominante);
            box-shadow: var(--ombre-promo);
        }

        .marques-nav-prev {
            left: 0;
        }

        .marques-nav-next {
            right: 0;
        }

        .marques-carousel.owl-carousel .owl-stage-outer {
            overflow: hidden;
        }

        .marques-carousel.owl-carousel .owl-nav {
            display: none;
        }

        .marques-carousel.owl-carousel .owl-dots {
            display: none;
        }

        .marque-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 28px 20px;
            text-align: center;
        }

        .marque-item-link {
            text-decoration: none;
            color: inherit;
            transition: transform 0.2s ease;
        }

        .marque-item-link:hover {
            transform: translateY(-2px);
        }

        .marque-item-link:hover .marque-name {
            color: var(--couleur-dominante);
        }

        .marque-logo-wrap {
            width: 130px;
            height: 130px;
            border-radius: 50%;
            border: 1px solid var(--glass-border);
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 16px;
            overflow: hidden;
            background: var(--blanc-casse);
        }

        .marque-logo-wrap img {
            width: 70%;
            height: 70%;
            object-fit: contain;
        }

        .marque-fallback {
            display: none;
            font-size: 26px;
            font-weight: 700;
            color: var(--couleur-dominante);
            letter-spacing: 1px;
        }

        .marque-name {
            font-size: 13px;
            font-weight: 600;
            color: var(--gris-fonce);
            letter-spacing: 0.5px;
            text-transform: uppercase;
            line-height: 1.3;
        }

        @media (max-width: 768px) {
            .marques-section {
                padding: 45px 0 55px;
            }

            .marques-container {
                padding: 0 50px;
            }

            .marques-nav {
                width: 44px;
                height: 44px;
                font-size: 14px;
            }

            .marque-item {
                padding: 22px 16px;
            }

            .marque-logo-wrap {
                width: 100px;
                height: 100px;
                margin-bottom: 14px;
            }

            .marque-fallback {
                font-size: 22px;
            }

            .marque-name {
                font-size: 11px;
            }
        }

        /* —— Accueil marketplace (grilles type vitrine B2B, ex. Alibaba) —— */
        .visually-hidden {
            position: absolute;
            width: 1px;
            height: 1px;
            padding: 0;
            margin: -1px;
            overflow: hidden;
            clip: rect(0, 0, 0, 0);
            white-space: nowrap;
            border: 0;
        }

        .mp-main {
            background: var(--blanc-neige);
            padding-bottom: 48px;
            font-family: var(--font-corps);
        }

        .mp-shell {
            box-sizing: border-box;
            width: 100%;
            max-width: 1320px;
            margin: 0 auto;
            padding: 0 16px;
            overflow-x: hidden;
        }

        .mp-slider-wrap:not(.mp-hero-slider-wrap) {
            max-width: 1320px;
            margin: 0 auto 12px;
            padding: 12px 16px 0;
        }

        .mp-slider-wrap:not(.mp-hero-slider-wrap) .slider-area.owl-carousel {
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.08);
            max-height: 320px;
        }

        .mp-slider-wrap:not(.mp-hero-slider-wrap) .slider-item img {
            width: 100%;
            max-height: 320px;
            object-fit: cover;
            display: block;
        }

        .mp-hero-inner {
            max-width: 920px;
            margin: 0 auto;
            text-align: center;
        }

        .mp-hero .mp-hero-sub {
            font-size: 14px;
            color: var(--gris-fonce);
            margin: 0 0 20px;
            line-height: 1.5;
        }

        /* Catégories populaires — collées sous le hero */
        .mp-popular-categories {
            background: var(--blanc);
            border-top: 1px solid var(--glass-border);
            border-bottom: 1px solid var(--glass-border);
            padding: 8px 0 10px;
            margin: 0;
            position: relative;
            z-index: 15;
        }

        .mp-popular-categories-inner {
            box-sizing: border-box;
            width: 100%;
            max-width: 1320px;
            margin: 0 auto;
            padding: 0 16px;
            position: relative;
            z-index: 1;
        }

        .mp-popular-categories-track {
            display: flex;
            align-items: flex-start;
            justify-content: flex-start;
            gap: clamp(8px, 2vw, 16px);
            overflow-x: auto;
            overflow-y: hidden;
            -webkit-overflow-scrolling: touch;
            scroll-snap-type: x proximity;
            scrollbar-width: none;
            padding: 2px 0 4px;
            position: relative;
            z-index: 2;
        }

        .mp-popular-categories-track::-webkit-scrollbar {
            display: none;
        }

        .mp-pop-cat-item {
            flex: 0 0 auto;
            width: clamp(64px, 12vw, 92px);
            max-width: 92px;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 6px;
            text-decoration: none;
            color: var(--titres);
            scroll-snap-align: start;
            min-width: 0;
            position: relative;
            z-index: 1;
            pointer-events: auto;
            box-sizing: border-box;
            padding: 0 2px;
            overflow: hidden;
        }

        .mp-pop-cat-icon {
            width: clamp(48px, 9vw, 60px);
            height: clamp(48px, 9vw, 60px);
            border-radius: 12px;
            background: rgba(255, 255, 255, 0.32);
            backdrop-filter: blur(14px);
            -webkit-backdrop-filter: blur(14px);
            border: 1px solid rgba(255, 255, 255, 0.55);
            box-shadow: 0 4px 18px rgba(53, 100, 166, 0.1);
            display: inline-flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
            transition: transform 0.2s ease, box-shadow 0.2s ease, background 0.2s ease;
        }

        .mp-pop-cat-icon i {
            font-size: clamp(22px, 4vw, 28px);
            line-height: 1;
        }

        .mp-pop-cat-icon--photo {
            overflow: hidden;
            padding: 0;
            background: var(--blanc-casse);
        }

        .mp-pop-cat-icon--photo img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
        }

        .mp-pop-cat-item:not(.mp-pop-cat-item--all):hover .mp-pop-cat-icon--photo {
            transform: scale(1.04);
            box-shadow: 0 6px 22px rgba(53, 100, 166, 0.16);
        }

        .mp-pop-cat-item:not(.mp-pop-cat-item--all):nth-child(7n + 1) .mp-pop-cat-icon i {
            color: var(--nav-soft-fg-1);
        }

        .mp-pop-cat-item:not(.mp-pop-cat-item--all):nth-child(7n + 2) .mp-pop-cat-icon i {
            color: var(--nav-soft-fg-2);
        }

        .mp-pop-cat-item:not(.mp-pop-cat-item--all):nth-child(7n + 3) .mp-pop-cat-icon i {
            color: var(--nav-soft-fg-3);
        }

        .mp-pop-cat-item:not(.mp-pop-cat-item--all):nth-child(7n + 4) .mp-pop-cat-icon i {
            color: var(--nav-soft-fg-4);
        }

        .mp-pop-cat-item:not(.mp-pop-cat-item--all):nth-child(7n + 5) .mp-pop-cat-icon i {
            color: var(--nav-soft-fg-5);
        }

        .mp-pop-cat-item:not(.mp-pop-cat-item--all):nth-child(7n + 6) .mp-pop-cat-icon i {
            color: var(--nav-soft-fg-6);
        }

        .mp-pop-cat-item:not(.mp-pop-cat-item--all):nth-child(7n + 7) .mp-pop-cat-icon i {
            color: var(--nav-soft-fg-7);
        }

        .mp-pop-cat-item:not(.mp-pop-cat-item--all):hover .mp-pop-cat-icon {
            transform: scale(1.04);
            background: rgba(255, 255, 255, 0.48);
            box-shadow: 0 6px 22px rgba(53, 100, 166, 0.16);
        }

        .mp-pop-cat-item--all .mp-pop-cat-icon {
            background: rgba(255, 255, 255, 0.32);
            color: var(--couleur-dominante);
        }

        .mp-pop-cat-item--all:hover .mp-pop-cat-icon {
            transform: scale(1.04);
            background: rgba(255, 255, 255, 0.48);
            box-shadow: 0 6px 22px rgba(53, 100, 166, 0.16);
        }

        .mp-pop-cat-label {
            display: block;
            width: 100%;
            max-width: 100%;
            box-sizing: border-box;
            padding: 0;
            font-size: clamp(10px, 1.6vw, 12px);
            font-weight: 500;
            text-align: center;
            line-height: 1.25;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            text-transform: none;
        }

        /* GTranslate enveloppe parfois le libellé dans <font> — rester dans le clamp 2 lignes */
        .mp-pop-cat-label font {
            display: inline;
            white-space: normal;
        }

        /* Icône grille 2×2 — bouton Voir tout */
        .mp-pop-grid-dots {
            display: grid;
            grid-template-columns: repeat(2, 5px);
            grid-template-rows: repeat(2, 5px);
            gap: 4px;
        }

        .mp-pop-grid-dots span {
            width: 5px;
            height: 5px;
            border-radius: 50%;
            background: currentColor;
        }

        .mp-pop-cat-item--all .mp-pop-cat-label {
            color: var(--couleur-dominante);
            font-weight: 600;
        }

        .mp-pop-cat-item--all {
            border: none;
            background: none;
            padding: 0 clamp(5px, 1.4vw, 10px);
            cursor: pointer;
            font-family: inherit;
            box-sizing: border-box;
            overflow: hidden;
        }

        @media (min-width: 768px) {
            .mp-popular-categories-track {
                justify-content: space-between;
                overflow-x: visible;
                flex-wrap: nowrap;
            }

            .mp-pop-cat-item {
                flex: 1 1 0;
                width: auto;
                min-width: 0;
                max-width: 96px;
            }
        }

        @media (max-width: 767px) {
            .mp-popular-categories-track {
                justify-content: space-between;
                overflow-x: visible;
                flex-wrap: nowrap;
                gap: 6px;
            }

            .mp-pop-cat-item:nth-child(n + 5):not(.mp-pop-cat-item--all) {
                display: none;
            }

            .mp-pop-cat-item {
                flex: 1 1 0;
                width: auto;
                min-width: 0;
                max-width: none;
                padding: 0 2px;
            }

            .mp-pop-cat-label {
                font-size: clamp(10px, 2.6vw, 11px);
            }
        }

        @media (min-width: 1100px) {
            .mp-popular-categories {
                padding: 8px 0 10px;
            }
        }

        @media (max-width: 479px) {
            .mp-popular-categories {
                padding: 6px 0 8px;
            }

            .mp-popular-categories-track {
                gap: 8px;
                margin: 0;
                padding: 2px clamp(4px, 1.5vw, 8px) 4px;
            }

            .mp-pop-cat-item {
                padding: 0 1px;
            }
        }

        .mp-search {
            display: flex;
            flex-wrap: wrap;
            gap: 0;
            max-width: 720px;
            margin: 0 auto;
            background: var(--blanc);
            border: 2px solid var(--couleur-dominante);
            border-radius: 32px;
            overflow: hidden;
            box-shadow: var(--glass-shadow);
        }

        .mp-search-input {
            flex: 1 1 200px;
            border: none;
            padding: 14px 20px;
            font-size: 15px;
            outline: none;
            min-width: 0;
        }

        .mp-search-btn {
            border: none;
            background: var(--couleur-dominante);
            color: var(--texte-clair);
            font-weight: 600;
            padding: 14px 24px;
            cursor: pointer;
            font-size: 15px;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            transition: background 0.2s ease;
        }

        .mp-search-btn:hover {
            background: var(--couleur-dominante-hover);
        }

        .mp-trust-row {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 12px 28px;
            max-width: 920px;
            margin: 20px auto 0;
        }

        .mp-trust-item {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            font-size: 13px;
            color: var(--gris-fonce);
        }

        .mp-trust-item i {
            color: var(--bleu-clair);
            font-size: 16px;
        }

        /* (Grille catégories pleine largeur retirée : voir vitrine mp-showcase) */

        /* Sections produits */
        .mp-block {
            margin: 22px 0 0;
        }

        .mp-block-head {
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: nowrap;
            gap: 10px 12px;
            margin-bottom: 14px;
            padding: 0 2px;
        }

        .mp-block-head h2 {
            margin: 0;
            flex: 1 1 auto;
            min-width: 0;
            font-size: clamp(16px, 4.2vw, 18px);
            font-weight: 700;
            color: var(--titres);
            font-family: var(--font-titres);
            line-height: 1.25;
        }

        .mp-block-more {
            flex: 0 0 auto;
            white-space: nowrap;
            font-size: 14px;
            font-weight: 600;
            color: var(--couleur-dominante);
            text-decoration: none;
        }

        .mp-block-more:hover {
            text-decoration: underline;
        }

        .mp-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
            gap: 12px;
        }

        @media (min-width: 1400px) {
            .mp-grid {
                grid-template-columns: repeat(6, 1fr);
            }
        }

        .mp-card {
            position: relative;
            background: var(--blanc);
            border: 1px solid var(--glass-border);
            border-radius: 10px;
            overflow: hidden;
            display: flex;
            flex-direction: column;
            transition: box-shadow 0.2s ease, border-color 0.2s ease;
        }

        .mp-card:hover {
            box-shadow: var(--ombre-douce);
            border-color: var(--bleu-pale);
        }

        .mp-card-link {
            text-decoration: none;
            color: inherit;
            flex: 1 1 auto;
            display: flex;
            flex-direction: column;
        }

        .mp-card-img {
            position: relative;
            aspect-ratio: 1 / 1;
            background: var(--blanc-casse);
            overflow: hidden;
        }

        .mp-card-badge {
            position: absolute;
            top: 8px;
            left: 8px;
            z-index: 2;
            font-size: 9px;
            font-weight: 800;
            letter-spacing: 0.05em;
            text-transform: uppercase;
            padding: 4px 8px;
            border-radius: 6px;
            pointer-events: none;
            line-height: 1.2;
        }

        .mp-card-badge--nouveau {
            background: var(--accent-promo);
            color: var(--blanc);
            box-shadow: 0 2px 8px rgba(255, 107, 53, 0.35);
        }

        .mp-card-img img {
            width: 100%;
            height: 100%;
            object-fit: contain;
            object-position: center;
            display: block;
        }

        .mp-card-body {
            padding: 10px 12px 8px;
            flex: 1;
            display: flex;
            flex-direction: column;
        }

        .mp-card-title {
            margin: 0 0 6px;
            font-size: 13px;
            font-weight: 500;
            line-height: 1.35;
            color: var(--noir-clair);
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
            min-height: 2.7em;
        }

        .mp-card .produit-card-boutique {
            font-size: 11px;
            margin: 0 0 4px;
            color: var(--gris-moyen);
            line-height: 1.3;
        }

        .mp-card .produit-card-boutique-link {
            color: var(--bleu-clair);
            font-weight: 600;
            text-decoration: none;
        }

        .mp-card .produit-card-boutique-link:hover {
            text-decoration: underline;
        }

        .mp-card-meta {
            margin: 0 0 8px;
            font-size: 11px;
            color: var(--gris-clair);
        }

        .mp-card-price-row {
            margin-top: auto;
            display: flex;
            flex-wrap: wrap;
            align-items: baseline;
            gap: 6px 10px;
        }

        .mp-card-price {
            font-size: 16px;
            font-weight: 700;
            color: var(--accent-promo);
        }

        .mp-card-price-old {
            font-size: 12px;
            color: var(--gris-clair);
            text-decoration: line-through;
        }

        .mp-card-cart {
            padding: 0 10px 10px;
            margin: 0;
        }

        .mp-card-btn {
            width: 100%;
            border: 1px solid var(--couleur-dominante);
            background: var(--blanc);
            color: var(--couleur-dominante);
            font-weight: 600;
            font-size: 13px;
            padding: 8px 10px;
            border-radius: 8px;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            transition: background 0.2s, color 0.2s;
        }

        .mp-card-btn:hover {
            background: var(--couleur-dominante);
            color: var(--texte-clair);
        }

        .mp-empty {
            grid-column: 1 / -1;
            text-align: center;
            padding: 36px 16px;
            color: var(--gris-moyen);
            background: var(--blanc);
            border: 1px dashed var(--glass-border);
            border-radius: 10px;
        }

        /* Bannières « Offres du moment » / « Nouveautés » (sous la 3e ligne de « Nos produits ») */
        .mp-duo {
            grid-column: 1 / -1;
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 14px;
            margin: 6px 0;
        }

        .mp-duo__card {
            position: relative;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 16px;
            min-height: 168px;
            padding: 22px 24px;
            border-radius: 20px;
            overflow: hidden;
            text-decoration: none;
            isolation: isolate;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }

        .mp-duo__card:hover {
            transform: translateY(-3px);
            box-shadow: 0 16px 32px rgba(16, 24, 40, 0.16);
        }

        .mp-duo__card--promo {
            background: linear-gradient(120deg, #142b4a 0%, #1e3a5f 45%, var(--couleur-dominante, #3564a6) 100%);
            color: #fff;
        }

        .mp-duo__glow {
            position: absolute;
            right: -40px;
            top: 50%;
            z-index: -1;
            width: 240px;
            height: 240px;
            border-radius: 50%;
            background: radial-gradient(circle, rgba(255, 107, 53, 0.65) 0%, rgba(255, 107, 53, 0) 68%);
            transform: translateY(-50%);
        }

        .mp-duo__card--new {
            background:
                radial-gradient(260px 180px at 90% 20%, rgba(255, 107, 53, 0.14), transparent 70%),
                linear-gradient(120deg, #f4f7fd, #e7eef9);
            color: #101828;
            border: 1px solid #dfe6f2;
        }

        .mp-duo__text {
            position: relative;
            z-index: 1;
            display: flex;
            flex-direction: column;
            align-items: flex-start;
            gap: 8px;
            min-width: 0;
            text-align: left;
        }

        .mp-duo__eyebrow {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            font-size: 12px;
            font-weight: 700;
            letter-spacing: 0.08em;
            text-transform: uppercase;
            color: #ff8a5c;
        }

        .mp-duo__card--new .mp-duo__eyebrow {
            color: var(--couleur-dominante, #3564a6);
        }

        .mp-duo__title {
            margin: 0;
            font-family: var(--font-titres);
            font-size: clamp(19px, 1.9vw, 25px);
            font-weight: 800;
            line-height: 1.12;
            color: inherit;
        }

        .mp-duo__sub {
            margin: 0;
            font-size: 13px;
            color: #475467;
        }

        .mp-duo__stats {
            display: flex;
            gap: 6px;
            margin: 2px 0 0;
            padding: 0;
            list-style: none;
        }

        .mp-duo__stats li {
            display: flex;
            flex-direction: column;
            align-items: center;
            min-width: 54px;
            padding: 5px 9px;
            border: 1px solid rgba(255, 255, 255, 0.22);
            border-radius: 10px;
            background: rgba(255, 255, 255, 0.08);
            line-height: 1.1;
        }

        .mp-duo__stats strong {
            font-size: 16px;
            font-weight: 800;
            color: #fff;
        }

        .mp-duo__stats span {
            font-size: 10px;
            color: rgba(255, 255, 255, 0.75);
        }

        .mp-duo__cta {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            margin-top: 4px;
            height: 38px;
            padding: 0 16px;
            border-radius: 999px;
            background: #fff;
            color: #101828;
            font-size: 13px;
            font-weight: 700;
            box-shadow: 0 6px 16px rgba(0, 0, 0, 0.15);
        }

        .mp-duo__card--new .mp-duo__cta {
            background: #101828;
            color: #fff;
        }

        .mp-duo__card:hover .mp-duo__cta i {
            transform: translateX(3px);
        }

        .mp-duo__cta i {
            transition: transform 0.2s ease;
        }

        .mp-duo__visual {
            position: relative;
            flex: none;
            width: 132px;
            height: 132px;
            border-radius: 50%;
            background: #fff;
            box-shadow: 0 14px 30px rgba(10, 25, 50, 0.28);
        }

        .mp-duo__card--promo .mp-duo__visual {
            outline: 6px solid rgba(255, 255, 255, 0.12);
        }

        .mp-duo__visual img {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            object-fit: cover;
            transition: transform 0.35s ease;
        }

        .mp-duo__card:hover .mp-duo__visual img {
            transform: scale(1.05);
        }

        .mp-duo__badge {
            position: absolute;
            top: -4px;
            right: -6px;
            display: grid;
            place-items: center;
            width: 46px;
            height: 46px;
            background: #ff6b35;
            color: #fff;
            font-size: 11px;
            font-weight: 800;
            letter-spacing: 0.04em;
            clip-path: polygon(50% 0%, 61% 12%, 77% 6%, 80% 22%, 96% 26%, 90% 41%, 100% 54%, 87% 64%, 90% 80%, 74% 82%, 66% 97%, 50% 88%, 34% 97%, 26% 82%, 10% 80%, 13% 64%, 0% 54%, 10% 41%, 4% 26%, 20% 22%, 23% 6%, 39% 12%);
        }

        @media (max-width: 767px) {
            .mp-duo {
                grid-template-columns: 1fr;
                gap: 10px;
            }

            .mp-duo__card {
                min-height: 0;
                padding: 16px 18px;
                border-radius: 18px;
            }

            .mp-duo__visual {
                width: 84px;
                height: 84px;
            }

            .mp-duo__sub {
                display: none;
            }

            .mp-duo__cta {
                height: 34px;
                padding: 0 14px;
            }

            .mp-duo__title {
                font-size: 18px;
            }

            .mp-duo__title br {
                display: none;
            }

            .mp-duo__badge {
                width: 38px;
                height: 38px;
                font-size: 10px;
            }
        }

        /* Rangée de 4 tuiles « rayons » (sous la 1re ligne de « Nos produits ») */
        .mp-quad {
            grid-column: 1 / -1;
            display: grid;
            grid-template-columns: repeat(4, minmax(0, 1fr));
            gap: 14px;
            margin: 6px 0;
        }

        .mp-quad[hidden] {
            display: none;
        }

        .mp-quad__tile {
            position: relative;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 10px;
            min-height: 150px;
            padding: 18px 16px 18px 20px;
            border-radius: 18px;
            overflow: hidden;
            text-decoration: none;
            color: #101828;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }

        .mp-quad__tile:hover {
            transform: translateY(-3px);
            box-shadow: 0 14px 28px rgba(16, 24, 40, 0.14);
        }

        .mp-quad__tile--rose { background: linear-gradient(135deg, #fbecee, #f3d9de); }
        .mp-quad__tile--sable { background: linear-gradient(135deg, #f7f1e8, #ece0cd); }
        .mp-quad__tile--gris { background: linear-gradient(135deg, #f3f4f6, #e2e5ea); }
        .mp-quad__tile--vendre {
            background:
                radial-gradient(200px 140px at 100% 100%, rgba(255, 107, 53, 0.35), transparent 70%),
                linear-gradient(135deg, #142b4a, var(--couleur-dominante, #3564a6));
            color: #fff;
        }

        .mp-quad__text {
            position: relative;
            z-index: 1;
            display: flex;
            flex-direction: column;
            align-items: flex-start;
            gap: 6px;
            min-width: 0;
            text-align: left;
        }

        .mp-quad__brand {
            font-family: var(--font-titres);
            font-size: 18px;
            font-weight: 800;
            letter-spacing: -0.01em;
            color: #ff8a5c;
        }

        .mp-quad__brand b {
            color: #fff;
        }

        .mp-quad__brand i {
            margin-left: 2px;
            font-size: 14px;
            color: #fff;
        }

        .mp-quad__title {
            font-family: var(--font-titres);
            font-size: 16px;
            font-weight: 800;
            line-height: 1.2;
        }

        .mp-quad__sub {
            font-size: 12px;
            line-height: 1.35;
            color: #475467;
        }

        .mp-quad__tile--vendre .mp-quad__sub {
            color: rgba(255, 255, 255, 0.82);
        }

        .mp-quad__btn {
            display: inline-flex;
            align-items: center;
            height: 30px;
            margin-top: 6px;
            padding: 0 13px;
            border-radius: 8px;
            font-size: 12px;
            font-weight: 700;
            white-space: nowrap;
            color: #fff;
        }

        .mp-quad__tile--rose .mp-quad__btn { background: #101828; }
        .mp-quad__tile--sable .mp-quad__btn { background: #c79a5b; }
        .mp-quad__tile--gris .mp-quad__btn { background: #6b7280; }
        .mp-quad__tile--vendre .mp-quad__btn { background: #ff6b35; }

        .mp-quad__img {
            flex: none;
            width: 96px;
            height: 96px;
            border-radius: 16px;
            overflow: hidden;
            box-shadow: 0 10px 22px rgba(16, 24, 40, 0.16);
            transform: rotate(4deg);
            transition: transform 0.3s ease;
        }

        .mp-quad__tile:hover .mp-quad__img {
            transform: rotate(0deg) scale(1.05);
        }

        .mp-quad__img img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .mp-quad__img--icon {
            display: grid;
            place-items: center;
            background: rgba(255, 255, 255, 0.12);
            color: #fff;
            font-size: 38px;
            box-shadow: none;
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        @media (max-width: 1199px) {
            .mp-quad {
                grid-template-columns: repeat(2, minmax(0, 1fr));
            }
        }

        @media (max-width: 767px) {
            .mp-quad {
                display: flex;
                gap: 10px;
                margin: 4px -12px;
                padding: 2px 12px 6px;
                overflow-x: auto;
                scroll-snap-type: x mandatory;
                scrollbar-width: none;
            }

            .mp-quad::-webkit-scrollbar {
                display: none;
            }

            .mp-quad__tile {
                flex: 0 0 82%;
                min-height: 128px;
                scroll-snap-align: start;
            }

            .mp-quad__img {
                width: 78px;
                height: 78px;
            }
        }

        /* Défilement infini de « Nos produits » : indicateur de chargement */
        .mp-infinite {
            display: flex;
            justify-content: center;
            gap: 6px;
            min-height: 24px;
            margin: 24px 0 8px;
        }

        .mp-infinite span {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background: var(--couleur-dominante);
            opacity: 0.25;
        }

        .mp-infinite.is-loading span {
            animation: mpInfiniteDot 0.9s ease-in-out infinite;
        }

        .mp-infinite.is-loading span:nth-child(2) { animation-delay: 0.15s; background: var(--accent-promo, #ff6b35); }
        .mp-infinite.is-loading span:nth-child(3) { animation-delay: 0.3s; }

        @keyframes mpInfiniteDot {
            0%, 100% { opacity: 0.25; transform: translateY(0); }
            50% { opacity: 1; transform: translateY(-5px); }
        }

        .mp-infinite[hidden] {
            display: none;
        }

        /* —— Vitrine (catégories + tendances + coups de cœur) : mobile-first = 1 colonne —— */
        .mp-showcase {
            padding: 20px 0 8px;
            overflow-x: hidden;
        }

        .mp-showcase-inner {
            display: grid;
            grid-template-columns: 1fr;
            gap: 16px;
            align-items: stretch;
            width: 100%;
            max-width: 100%;
            min-width: 0;
            box-sizing: border-box;
        }

        .mp-showcase-inner>* {
            min-width: 0;
        }

        @media (min-width: 1101px) {
            .mp-showcase-inner {
                grid-template-columns: 240px minmax(0, 3fr) minmax(0, 2fr);
            }

            .mp-showcase-inner.mp-showcase-inner--no-nav {
                grid-template-columns: minmax(0, 3fr) minmax(0, 2fr);
            }
        }

        /* Tablette : tendances puis boutiques sur une ligne dédiée pleine largeur */
        @media (min-width: 768px) and (max-width: 1100px) {
            .mp-showcase-inner.mp-showcase-inner--no-nav {
                grid-template-columns: 1fr;
                gap: 16px;
            }

            .mp-showcase-center {
                padding: 18px 16px 20px;
            }

            .mp-showcase-boutiques {
                min-height: auto;
                max-width: 100%;
                width: 100%;
            }

            .mp-pair-grid {
                grid-template-columns: 1fr 1fr;
                gap: 16px;
            }

            .mp-panel-products {
                grid-template-columns: repeat(2, minmax(0, 1fr));
                gap: 10px 12px;
            }

            .mp-grid {
                grid-template-columns: repeat(4, minmax(0, 1fr));
                gap: 14px;
            }
        }

        .mp-showcase-nav {
            background: var(--blanc);
            border: 1px solid var(--glass-border);
            border-radius: 12px;
            box-shadow: var(--glass-shadow);
            overflow: hidden;
            display: flex;
            flex-direction: column;
            max-height: 420px;
        }

        .mp-showcase-nav-head {
            font-size: 14px;
            font-weight: 700;
            color: var(--titres);
            padding: 14px 16px;
            border-bottom: 1px solid var(--glass-border);
            display: flex;
            align-items: center;
            gap: 8px;
            font-family: var(--font-titres);
        }

        .mp-showcase-nav-head i {
            color: var(--accent-promo);
        }

        .mp-showcase-nav-list {
            list-style: none;
            margin: 0;
            padding: 8px 0;
            overflow-y: auto;
            flex: 1;
        }

        .mp-showcase-nav-list li {
            margin: 0;
        }

        .mp-showcase-nav-list a {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 10px 14px;
            color: var(--gris-fonce);
            text-decoration: none;
            font-size: 13px;
            font-weight: 500;
            transition: background 0.15s, color 0.15s;
            border-bottom: 1px solid var(--blanc-casse);
        }

        .mp-showcase-nav-list a:hover {
            background: var(--bleu-pale);
            color: var(--couleur-dominante);
        }

        .mp-showcase-nav-list .mp-sn-ico {
            width: 44px;
            height: 44px;
            border-radius: 10px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
            background: var(--nav-soft-bg-1);
            color: var(--nav-soft-fg-1);
            border: 1px solid rgba(255, 255, 255, 0.85);
            box-shadow: var(--nav-soft-shadow);
            transition:
                box-shadow 0.2s ease,
                transform 0.2s ease;
        }

        .mp-showcase-nav-list li:nth-child(7n + 2) .mp-sn-ico {
            background: var(--nav-soft-bg-2);
            color: var(--nav-soft-fg-2);
        }

        .mp-showcase-nav-list li:nth-child(7n + 3) .mp-sn-ico {
            background: var(--nav-soft-bg-3);
            color: var(--nav-soft-fg-3);
        }

        .mp-showcase-nav-list li:nth-child(7n + 4) .mp-sn-ico {
            background: var(--nav-soft-bg-4);
            color: var(--nav-soft-fg-4);
        }

        .mp-showcase-nav-list li:nth-child(7n + 5) .mp-sn-ico {
            background: var(--nav-soft-bg-5);
            color: var(--nav-soft-fg-5);
        }

        .mp-showcase-nav-list li:nth-child(7n + 6) .mp-sn-ico {
            background: var(--nav-soft-bg-6);
            color: var(--nav-soft-fg-6);
        }

        .mp-showcase-nav-list li:nth-child(7n + 7) .mp-sn-ico {
            background: var(--nav-soft-bg-7);
            color: var(--nav-soft-fg-7);
        }

        .mp-showcase-nav-list a:hover .mp-sn-ico {
            box-shadow: var(--nav-soft-shadow-hover);
            transform: scale(1.02);
        }

        .mp-showcase-nav-list .mp-sn-ico i {
            font-size: 17px;
            line-height: 1;
        }

        .mp-showcase-nav-list .mp-sn-chev {
            margin-left: auto;
            color: var(--gris-clair);
            font-size: 11px;
        }

        .mp-showcase-nav-foot {
            padding: 10px 12px;
            border-top: 1px solid var(--glass-border);
        }

        .mp-showcase-nav-foot a {
            display: block;
            text-align: center;
            font-size: 13px;
            font-weight: 600;
            color: var(--couleur-dominante);
            text-decoration: none;
        }

        /* Après les styles .mp-showcase-nav : masquer sur mobile (accès via menu latéral) */
        @media (max-width: 768px) {
            .mp-showcase-nav {
                display: none !important;
            }
        }

        .mp-showcase-center {
            background: var(--blanc);
            border: 1px solid var(--glass-border);
            border-radius: 12px;
            padding: 16px 14px 18px;
            box-shadow: var(--glass-shadow);
            position: relative;
        }

        .mp-showcase-center-top {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            gap: 12px;
            margin-bottom: 14px;
        }

        .mp-showcase-center-top h2 {
            margin: 0;
            font-size: 16px;
            font-weight: 700;
            color: var(--titres);
            font-family: var(--font-titres);
        }

        .mp-showcase-center-top p {
            margin: 4px 0 0;
            font-size: 12px;
            color: var(--gris-moyen);
        }

        .mp-trend-nav {
            display: flex;
            gap: 6px;
        }

        .mp-trend-nav button {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            border: 1px solid var(--glass-border);
            background: var(--blanc);
            color: var(--titres);
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: var(--ombre-douce);
            transition: background 0.2s, color 0.2s;
        }

        .mp-trend-nav button:hover {
            background: var(--couleur-dominante);
            color: var(--texte-clair);
            border-color: var(--couleur-dominante);
        }

        .mp-trend-scroll {
            display: flex;
            gap: 12px;
            overflow-x: auto;
            scroll-snap-type: x mandatory;
            scroll-behavior: smooth;
            padding-bottom: 6px;
            margin: 0 -4px;
            padding-left: 4px;
            padding-right: 4px;
            -webkit-overflow-scrolling: touch;
        }

        .mp-trend-scroll::-webkit-scrollbar {
            height: 6px;
        }

        .mp-trend-scroll::-webkit-scrollbar-thumb {
            background: var(--bleu-pale);
            border-radius: 4px;
        }

        .mp-trend-card {
            flex: 0 0 168px;
            scroll-snap-align: start;
            background: var(--blanc);
            border: 1px solid var(--glass-border);
            border-radius: 12px;
            padding: 12px 10px;
            text-align: center;
        }

        .mp-trend-label {
            display: block;
            font-size: 11px;
            font-weight: 700;
            color: var(--couleur-dominante);
            text-transform: uppercase;
            letter-spacing: 0.04em;
            margin-bottom: 4px;
        }

        .mp-trend-sub {
            font-size: 12px;
            font-weight: 600;
            color: var(--titres);
            margin-top: 10px;
            margin-bottom: 0;
            line-height: 1.35;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
            min-height: 2.6em;
        }

        .mp-trend-card a.mp-trend-img-link {
            display: block;
            aspect-ratio: 1 / 1;
            background: var(--blanc);
            border-radius: 10px;
            overflow: hidden;
            border: 0;
        }

        .mp-trend-card a.mp-trend-img-link img {
            width: 100%;
            height: 100%;
            object-fit: contain;
            object-position: center;
        }

        .mp-trend-card--featured {
            border-color: var(--couleur-dominante);
            box-shadow: var(--ombre-douce);
        }

        .mp-showcase-center .mp-trend-scroll {
            scroll-padding-left: 4px;
        }

        @media (min-width: 720px) {
            .mp-showcase-center .mp-trend-card {
                flex: 0 0 calc((100% - 36px) / 4);
                max-width: calc((100% - 36px) / 4);
            }
        }

        /* Panneau boutiques : css/boutiques-marketplace.css */

        /* « Top des ventes » : classement horizontal (rangs or / argent / bronze) */
        .mp-top {
            position: relative;
            margin: 22px 0;
            padding: 26px 0 24px 28px;
            border-radius: 22px;
            overflow: hidden;
            background:
                radial-gradient(520px 260px at 100% 0%, rgba(255, 107, 53, 0.35), transparent 60%),
                radial-gradient(420px 240px at 0% 100%, rgba(255, 255, 255, 0.10), transparent 60%),
                linear-gradient(125deg, #1e3a5f, var(--couleur-dominante, #3564a6));
            color: #fff;
        }

        .mp-top__head {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 16px;
            margin: 0 28px 18px 0;
        }

        .mp-top__title {
            display: flex;
            align-items: center;
            gap: 12px;
            margin: 0;
            font-family: var(--font-titres);
            font-size: clamp(20px, 2.6vw, 26px);
            font-weight: 700;
            line-height: 1.15;
            color: #fff;
        }

        .mp-top__trophy {
            display: grid;
            place-items: center;
            width: 42px;
            height: 42px;
            border-radius: 13px;
            background: linear-gradient(135deg, #ffb547, #ff6b35);
            color: #fff;
            font-size: 18px;
            box-shadow: 0 8px 18px rgba(255, 107, 53, 0.4);
        }

        .mp-top__actions {
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .mp-top__nav {
            display: grid;
            place-items: center;
            width: 38px;
            height: 38px;
            border: 1px solid rgba(255, 255, 255, 0.28);
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.10);
            color: #fff;
            cursor: pointer;
            transition: background 0.15s ease;
        }

        .mp-top__nav:hover {
            background: rgba(255, 255, 255, 0.24);
        }

        .mp-top__all {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            height: 38px;
            padding: 0 16px;
            border-radius: 999px;
            background: #fff;
            color: var(--couleur-dominante, #3564a6) !important;
            font-size: 13px;
            font-weight: 700;
            text-decoration: none;
        }

        .mp-top__all:hover {
            color: #ff6b35 !important;
        }

        .mp-top__track {
            display: flex;
            gap: 14px;
            padding: 6px 28px 6px 0;
            overflow-x: auto;
            scroll-snap-type: x mandatory;
            scroll-behavior: smooth;
            scrollbar-width: none;
        }

        .mp-top__track::-webkit-scrollbar {
            display: none;
        }

        .mp-top-card {
            position: relative;
            box-sizing: border-box;
            display: flex;
            flex: 0 0 188px;
            flex-direction: column;
            width: 188px;
            min-width: 188px;
            max-width: 188px;
            height: 278px;
            padding: 0;
            border: 0;
            border-radius: 18px;
            background: #fff;
            color: #101828;
            text-decoration: none;
            text-align: left;
            overflow: hidden;
            scroll-snap-align: start;
            align-self: flex-start;
            box-shadow: 0 10px 24px rgba(10, 25, 50, 0.22);
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }

        .mp-top-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 16px 30px rgba(10, 25, 50, 0.3);
        }

        .mp-top-card__rank {
            position: absolute;
            top: 10px;
            left: 10px;
            z-index: 1;
            display: grid;
            place-items: center;
            min-width: 30px;
            height: 30px;
            padding: 0 8px;
            border-radius: 10px;
            background: var(--couleur-dominante, #3564a6);
            color: #fff;
            font-size: 14px;
            font-weight: 800;
            box-shadow: 0 4px 10px rgba(16, 24, 40, 0.2);
        }

        .mp-top-card--1 .mp-top-card__rank { background: linear-gradient(135deg, #ffd56b, #f0a500); }
        .mp-top-card--2 .mp-top-card__rank { background: linear-gradient(135deg, #e4e7ec, #98a2b3); }
        .mp-top-card--3 .mp-top-card__rank { background: linear-gradient(135deg, #f3b38a, #c2703d); }

        .mp-top-card__img {
            flex: none;
            width: calc(100% - 16px);
            height: 172px;
            margin: 8px 8px 0;
            border-radius: 13px;
            background: #f4f6fa;
            overflow: hidden;
        }

        .mp-top-card__img img {
            display: block;
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.3s ease;
        }

        .mp-top-card:hover .mp-top-card__img img {
            transform: scale(1.04);
        }

        .mp-top-card__body {
            text-align: left;
            display: flex;
            flex: 1 1 auto;
            flex-direction: column;
            gap: 4px;
            min-height: 0;
            padding: 8px 12px 12px;
            overflow: hidden;
        }

        .mp-top-card__title {
            margin: 0;
            font-size: 13px;
            font-weight: 600;
            line-height: 1.35;
            color: #101828;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
            height: 35px;
        }

        .mp-top-card__body .pr-stars {
            flex: none;
            max-height: 18px;
            overflow: hidden;
        }

        .mp-top-card__price {
            display: flex;
            flex-wrap: wrap;
            align-items: baseline;
            gap: 6px;
            margin: auto 0 0;
        }

        .mp-top-card__price strong {
            font-size: 15px;
            font-weight: 800;
            color: #ff6b35;
        }

        .mp-top-card__price s {
            font-size: 11px;
            color: #98a2b3;
        }

        @media (max-width: 767px) {
            .mp-top {
                margin: 16px 0;
                padding: 20px 0 18px 16px;
                border-radius: 18px;
            }

            .mp-top__head {
                margin-right: 16px;
                margin-bottom: 14px;
            }

            .mp-top__trophy {
                width: 36px;
                height: 36px;
                font-size: 15px;
            }

            .mp-top__nav {
                display: none;
            }

            .mp-top__track {
                gap: 10px;
                padding-right: 16px;
            }

            .mp-top-card {
                flex: 0 0 150px;
                width: 150px;
                min-width: 150px;
                max-width: 150px;
                height: 248px;
                border-radius: 16px;
            }

            .mp-top-card__img {
                height: 134px;
            }
        }

        /* Deux panneaux : Top + Nouveautés */
        .mp-pair {
            margin: 8px 0 24px;
        }

        .mp-pair-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 18px;
        }

        @media (max-width: 767px) {
            .mp-pair-grid {
                grid-template-columns: 1fr;
            }
        }

        .mp-panel {
            background: var(--blanc);
            border: 1px solid var(--glass-border);
            border-radius: 14px;
            padding: 20px 18px 22px;
            box-shadow: var(--glass-shadow);
        }

        .mp-panel-head {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            gap: 12px;
            margin-bottom: 18px;
        }

        .mp-panel-head h2 {
            margin: 0;
            font-size: 17px;
            font-weight: 700;
            color: var(--titres);
            font-family: var(--font-titres);
        }

        .mp-panel-head p {
            margin: 6px 0 0;
            font-size: 13px;
            color: var(--gris-moyen);
            line-height: 1.4;
        }

        .mp-panel-more {
            font-size: 13px;
            font-weight: 600;
            color: var(--couleur-dominante);
            text-decoration: none;
            white-space: nowrap;
        }

        .mp-panel-more:hover {
            text-decoration: underline;
        }

        .mp-panel-products {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 12px 14px;
        }

        @media (min-width: 1101px) {
            .mp-panel-products {
                grid-template-columns: repeat(4, minmax(0, 1fr));
                gap: 10px 12px;
            }
        }

        @media (max-width: 400px) {
            .mp-panel-products {
                gap: 8px 10px;
            }

            .mp-new-card {
                padding: 8px 6px;
            }

            .mp-new-price {
                font-size: 14px;
            }

            .mp-new-cart-btn {
                padding: 6px;
                font-size: 13px;
            }
        }

        /* Anciennes classes TOP (non utilisées par le strip actuel) */
        .mp-top-card-link {
            text-decoration: none;
            color: inherit;
            display: block;
        }

        .mp-top-card-img-wrap {
            position: relative;
            margin: 0 auto 14px;
            max-width: 160px;
        }

        /* Image sans cadre propre : un seul contour (celui de la carte) */
        .mp-top-card-img {
            aspect-ratio: 1 / 1;
            border-radius: 10px;
            overflow: hidden;
            background: var(--blanc);
        }

        .mp-top-card-img img {
            width: 100%;
            height: 100%;
            object-fit: contain;
            object-position: center;
        }

        .mp-top-badge {
            position: absolute;
            bottom: -10px;
            left: 50%;
            transform: translateX(-50%);
            background: linear-gradient(135deg, var(--bleu-fonce), var(--couleur-dominante));
            color: var(--texte-clair);
            font-size: 10px;
            font-weight: 800;
            letter-spacing: 0.06em;
            padding: 6px 14px;
            clip-path: polygon(10% 0%, 90% 0%, 100% 50%, 90% 100%, 10% 100%, 0% 50%);
            box-shadow: var(--ombre-douce);
        }

        .mp-top-title {
            margin: 14px 0 6px;
            font-size: 13px;
            font-weight: 700;
            color: var(--titres);
            line-height: 1.35;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }

        .mp-top-sub {
            margin: 0;
            font-size: 11px;
            color: var(--gris-moyen);
        }

        .mp-top-cart {
            margin: 12px 0 0;
        }

        .mp-top-cart-btn {
            width: 100%;
            border: none;
            background: var(--couleur-dominante);
            color: var(--texte-clair);
            font-size: 12px;
            font-weight: 600;
            padding: 8px 10px;
            border-radius: 8px;
            cursor: pointer;
            transition: background 0.2s;
        }

        .mp-top-cart-btn:hover {
            background: var(--couleur-dominante-hover);
        }

        /* Cartes nouveautés compactes */
        .mp-new-card {
            position: relative;
            border: 1px solid var(--glass-border);
            border-radius: 12px;
            padding: 10px;
            background: var(--blanc);
            display: flex;
            flex-direction: column;
        }

        .mp-new-badge {
            position: absolute;
            top: 8px;
            right: 8px;
            z-index: 2;
            background: var(--accent-promo);
            color: var(--blanc);
            font-size: 10px;
            font-weight: 700;
            letter-spacing: 0.04em;
            text-transform: uppercase;
            padding: 4px 8px;
            border-radius: 6px;
            box-shadow: none;
            pointer-events: none;
        }

        /* Badge « Populaire » (panneau Les plus consultés) */
        .mp-new-badge.mp-new-badge--top {
            background: var(--couleur-dominante);
        }

        .mp-new-old-price {
            margin: 2px 0 0;
            font-size: 12.5px;
            color: var(--gris-moyen, #737373);
            text-decoration: line-through;
        }

        .mp-new-cart-btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 7px;
            font-weight: 600;
        }

        .mp-panel-more {
            display: inline-flex;
            align-items: center;
            gap: 6px;
        }

        .mp-panel-more i {
            font-size: 12px;
        }

        .mp-new-card-link {
            text-decoration: none;
            color: inherit;
            flex: 1;
        }

        .mp-new-card-img {
            aspect-ratio: 1 / 1;
            border-radius: 10px;
            overflow: hidden;
            background: var(--blanc);
            margin-bottom: 10px;
        }

        .mp-new-card-img img {
            width: 100%;
            height: 100%;
            object-fit: contain;
            object-position: center;
        }

        .mp-new-title {
            margin: 0 0 8px;
            font-size: 13px;
            font-weight: 700;
            color: var(--titres);
            line-height: 1.35;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }

        .mp-new-promo {
            margin: 0 0 6px;
            font-size: 11px;
            font-weight: 600;
            color: var(--accent-promo);
        }

        .mp-new-price {
            margin: 0 0 4px;
            font-size: 16px;
            font-weight: 800;
            color: var(--titres);
        }

        .mp-new-price span {
            font-size: 12px;
            font-weight: 600;
            color: var(--gris-moyen);
        }

        .mp-new-cart {
            margin: 10px 0 0;
        }

        .mp-new-cart-btn {
            width: 100%;
            border: 1px solid var(--couleur-dominante);
            background: var(--blanc);
            color: var(--couleur-dominante);
            border-radius: 8px;
            padding: 8px;
            cursor: pointer;
            font-size: 15px;
            transition: background 0.2s, color 0.2s;
        }

        .mp-new-cart-btn:hover {
            background: var(--couleur-dominante);
            color: var(--texte-clair);
        }

        .mp-logos-wrap {
            margin: 20px 0 8px;
        }

        @media (max-width: 576px) {
            .mp-search {
                border-radius: 8px;
                flex-direction: column;
            }

            .mp-search-btn {
                justify-content: center;
                width: 100%;
            }

            .mp-grid {
                grid-template-columns: repeat(2, 1fr);
                gap: 10px;
            }
        }
    </style>

</head>


<body>

    <?php
    $section1_mp_page_title = SITE_BRAND_NAME . ' — Marketplace Sénégal';
    $nav_head_styles_loaded = true;
    include 'nav_bar.php';
    unset($section1_mp_page_title, $nav_head_styles_loaded);
    ?>

    <?php if (isset($_GET['error'])): ?>
        <div class="commande-perso-success"
            style="max-width: 600px; margin: 20px auto; padding: 15px 25px; background: var(--error-bg); border-left: 4px solid var(--error-border); border-radius: 8px; color: var(--titres);">
            <i class="fas fa-exclamation-circle"></i> <?php echo htmlspecialchars($_GET['error']); ?>
        </div>
    <?php endif; ?>
    <?php if (isset($_SESSION['commande_perso_success'])): ?>
        <div class="commande-perso-success"
            style="max-width: 600px; margin: 20px auto; padding: 15px 25px; background: var(--success-bg); border-left: 4px solid var(--bleu); border-radius: 8px; color: var(--titres);">
            <i class="fas fa-check-circle"></i>
            <?php echo htmlspecialchars($_SESSION['commande_perso_success']);
            unset($_SESSION['commande_perso_success']); ?>
        </div>
    <?php endif; ?>

    <?php
    require_once __DIR__ . '/includes/image_optimizer.php';

    $return_url_mp = (string) ($_SERVER['REQUEST_URI'] ?? '/index.php');

    $slides = [];
    if (file_exists(__DIR__ . '/models/model_slider.php')) {
        require_once __DIR__ . '/models/model_slider.php';
        $slides_result = get_all_slides('actif');
        $slides = is_array($slides_result) ? $slides_result : [];
    }

    $mp_categories = [];
    if (file_exists(__DIR__ . '/models/model_categories.php')) {
        require_once __DIR__ . '/models/model_categories.php';
        $mp_categories = get_all_categories();
        if (is_array($mp_categories) && count($mp_categories) > 24) {
            $mp_categories = array_slice($mp_categories, 0, 24);
        }
    }
    if (!is_array($mp_categories)) {
        $mp_categories = [];
    }

    $logos_carousel = [];
    if (file_exists(__DIR__ . '/models/model_logos.php')) {
        require_once __DIR__ . '/models/model_logos.php';
        $logos_carousel = get_all_logos('actif', null);
    }
    if (!is_array($logos_carousel)) {
        $logos_carousel = [];
    }

    $produits_nouveaux = [];
    $produits_populaires = [];
    $produits_tous = [];
    $total_produits = 0;
    $mp_home_catalog_grid_limit = 24;
    if (file_exists(__DIR__ . '/models/model_produits.php')) {
        require_once __DIR__ . '/models/model_produits.php';
        require_once __DIR__ . '/includes/catalogue_shuffle.php';
        $seed_tous = catalogue_nouveau_seed('index_tous');
        $produits_tous = get_all_produits_paginated(0, $mp_home_catalog_grid_limit, null, $seed_tous);
        $seed_nouveaux = catalogue_nouveau_seed('index_nouveaux');
        $produits_nouveaux = catalogue_melanger_produits($produits_tous, $seed_nouveaux);
        $total_produits = count_all_produits_actifs();
    }
    if (file_exists(__DIR__ . '/models/model_visites.php')) {
        require_once __DIR__ . '/models/model_visites.php';
        $produits_populaires = get_produits_plus_visites(12);
    }
    if (!is_array($produits_nouveaux)) {
        $produits_nouveaux = [];
    }
    if (!is_array($produits_populaires)) {
        $produits_populaires = [];
    }
    if (!is_array($produits_tous)) {
        $produits_tous = [];
    }
    if (!empty($produits_populaires) && file_exists(__DIR__ . '/includes/catalogue_shuffle.php')) {
        require_once __DIR__ . '/includes/catalogue_shuffle.php';
        $produits_populaires = catalogue_melanger_produits($produits_populaires);
    }

    $card_partial = __DIR__ . '/includes/partials/home_mp_product_card.php';
    $partial_top = __DIR__ . '/includes/partials/home_mp_top_product.php';
    $partial_newc = __DIR__ . '/includes/partials/home_mp_new_compact.php';

    $mp_nav_cats = [];
    $mp_nav_is_generale = false;
    if (function_exists('categories_generales_table_exists') && categories_generales_table_exists()) {
        $mp_nav_generales = get_general_categories_ordered();
        if (is_array($mp_nav_generales) && !empty($mp_nav_generales)) {
            $mp_nav_cats = array_slice($mp_nav_generales, 0, 14);
            $mp_nav_is_generale = true;
        }
    }
    if (empty($mp_nav_cats) && !empty($mp_categories)) {
        $mp_nav_cats = array_slice($mp_categories, 0, 14);
        $mp_nav_is_generale = false;
    }
    require_once __DIR__ . '/includes/marketplace_personalization.php';
    $mp_nav_cats = marketplace_personalization_order_categories($mp_nav_cats);
    $mp_personalization = marketplace_personalization_home_context();
    $mp_home_personalized = !empty($mp_personalization['warm']);
    $mp_popular_cats = marketplace_personalization_popular_categories($mp_nav_cats);

    require_once __DIR__ . '/includes/marketplace_home_helpers.php';
    if (file_exists(__DIR__ . '/models/model_recherches_catalogue.php')) {
        require_once __DIR__ . '/models/model_recherches_catalogue.php';
    }
    if (file_exists(__DIR__ . '/models/model_produits_avis.php')) {
        require_once __DIR__ . '/models/model_produits_avis.php';
    }

    /* Recherches fréquentes : produits liés aux termes les plus recherchés (ordre conservé) */
    $recherche_candidats = function_exists('get_produits_lies_aux_recherches_frequentes')
        ? get_produits_lies_aux_recherches_frequentes(40)
        : [];
    if ($mp_home_personalized && !empty($mp_personalization['produits_recommandes'])) {
        $produits_tendance = array_slice($mp_personalization['produits_recommandes'], 0, 20);
    } else {
        $produits_tendance = marketplace_produits_ordre_ou_aleatoire($recherche_candidats, 20, 'marketplace_recherches');
    }

    /* 4 articles / panneau : grille 2×2 sur mobile, 4 en ligne sur grand écran */
    $produits_top_panneau = !empty($produits_populaires)
        ? array_slice($produits_populaires, 0, 4)
        : array_slice($produits_nouveaux, 0, 4);
    $produits_new_panneau = function_exists('get_produits_nouveautes_aleatoires_panneau')
        ? get_produits_nouveautes_aleatoires_panneau(4, 50)
        : array_slice($produits_nouveaux, 0, 4);

    /* Bandeau B2B : best-sellers (quantités commandées), mélangés */
    $vendus_candidats = function_exists('get_produits_plus_vendus_marketplace')
        ? get_produits_plus_vendus_marketplace(60)
        : [];
    /* « Top des ventes » : le vrai classement (70 meilleurs produits), dans l'ordre */
    $produits_strip = function_exists('get_produits_top_ventes')
        ? get_produits_top_ventes(70)
        : marketplace_produits_aleatoires_avec_seuil($vendus_candidats, 8, 5);

    if ($mp_home_personalized && !empty($mp_personalization['produits_recommandes'])) {
        $produits_tous = marketplace_personalization_blend_catalogue(
            $produits_tous,
            $mp_personalization['produits_recommandes'],
            $mp_home_catalog_grid_limit
        );
    }
    $produits_tous = array_slice($produits_tous, 0, $mp_home_catalog_grid_limit);
    /* Bannières « Offres du moment » / « Nouveautés » sous la première ligne de « Nos produits » */
    $mp_duo = ['promo_count' => 0, 'promo_max' => 0, 'promo_img' => '', 'new_img' => '', 'new_nom' => ''];
    try {
        global $db;
        $r = $db->query("SELECT COUNT(*) AS n, MAX(ROUND((prix - prix_promotion) / prix * 100)) AS mx FROM produits
            WHERE statut = 'actif' AND prix_promotion > 0 AND prix_promotion < prix")->fetch(PDO::FETCH_ASSOC) ?: [];
        $mp_duo['promo_count'] = (int) ($r['n'] ?? 0);
        $mp_duo['promo_max'] = (int) ($r['mx'] ?? 0);
        $mp_duo['promo_img'] = (string) ($db->query("SELECT image_principale FROM produits
            WHERE statut = 'actif' AND prix_promotion > 0 AND prix_promotion < prix AND image_principale <> ''
            ORDER BY (prix - prix_promotion) / prix DESC LIMIT 1")->fetchColumn() ?: '');
        $r = $db->query("SELECT nom, image_principale FROM produits WHERE statut = 'actif' AND image_principale <> ''
            ORDER BY date_creation DESC LIMIT 1")->fetch(PDO::FETCH_ASSOC) ?: [];
        $mp_duo['new_img'] = (string) ($r['image_principale'] ?? '');
        $mp_duo['new_nom'] = (string) ($r['nom'] ?? '');
    } catch (Throwable $e) {
        error_log('[index mp_duo] ' . $e->getMessage());
    }

    /* Rangée de 4 tuiles sous la 8e ligne de « Nos produits » : 3 rayons tirés au hasard à chaque visite
       (parmi ceux qui ont des produits en ligne et une image) + « Vendez sur COLObanes » */
    $mp_quad_rayons = [];
    try {
        global $db;
        $mp_quad_rayons = $db->query("SELECT g.id, g.nom, g.image, COUNT(p.id) AS nb
            FROM categories_generales g
            JOIN categories c ON c.categorie_generale_id = g.id
            JOIN produits p ON p.categorie_id = c.id AND p.statut = 'actif'
            WHERE g.image IS NOT NULL AND g.image <> ''
            GROUP BY g.id, g.nom, g.image
            ORDER BY RAND() LIMIT 3")->fetchAll(PDO::FETCH_ASSOC) ?: [];
    } catch (Throwable $e) {
        error_log('[index mp_quad] ' . $e->getMessage());
    }

    /* Défilement infini : produits déjà affichés, pour que la suite ne les répète pas */
    if (session_status() === PHP_SESSION_ACTIVE) {
        $_SESSION['home_infinite'] = [
            'seed' => (int) ($seed_tous ?? 1),
            'vus' => array_values(array_map(static function ($p) {
                return (int) ($p['id'] ?? 0);
            }, $produits_tous)),
        ];
    }

    /* Boutiques partenaires — aperçu accueil */
    $boutiques_accueil = [];
    if (file_exists(__DIR__ . '/models/model_boutiques_marketplace.php')) {
        require_once __DIR__ . '/models/model_boutiques_marketplace.php';
        require_once __DIR__ . '/includes/marketplace_boutique_card_helpers.php';
        require_once __DIR__ . '/includes/marketplace_country_filter.php';
        $mp_country_boutiques = marketplace_get_selected_country_code();
        $boutiques_accueil = marketplace_boutiques_top_ventes(4, $mp_country_boutiques);
    }

    $hero_affiches = [];
    if (file_exists(__DIR__ . '/models/model_marketplace_hero.php')) {
        require_once __DIR__ . '/models/model_marketplace_hero.php';
        $hero_affiches = marketplace_hero_list_actifs();
    }
    if (!is_array($hero_affiches)) {
        $hero_affiches = [];
    }
    $hero_affiches = array_values(array_filter($hero_affiches, static function ($ha) {
        $img = trim(str_replace('\\', '/', (string) ($ha['image'] ?? '')));
        if ($img === '') {
            return false;
        }
        $rel = str_contains($img, '/') ? $img : 'marketplace_hero/' . $img;

        return function_exists('upload_image_local_exists') && upload_image_local_exists($rel);
    }));

    $showcase_site_pool = marketplace_build_showcase_pool(
        10,
        $produits_tendance,
        $mp_home_personalized ? ($mp_personalization['produits_recommandes'] ?? []) : [],
        $produits_populaires,
        $produits_nouveaux,
        $produits_tous,
        $recherche_candidats
    );
    $mp_showcase_pick = marketplace_home_showcase_produits($mp_home_personalized, $mp_personalization, $showcase_site_pool, 10);
    $produits_showcase_center = $mp_showcase_pick['produits'];
    $mp_showcase_featured_id = (int) ($mp_showcase_pick['featured_produit_id'] ?? 0);

    if (function_exists('produits_avis_enrich_products')) {
        $avis_stats = marketplace_avis_stats_for_product_lists([
            $produits_tendance,
            $produits_showcase_center,
            $produits_strip,
            $produits_top_panneau,
            $produits_new_panneau,
            $produits_tous,
        ]);
        $produits_tendance = marketplace_apply_avis_stats($produits_tendance, $avis_stats);
        $produits_showcase_center = marketplace_apply_avis_stats($produits_showcase_center, $avis_stats);
        $produits_strip = marketplace_apply_avis_stats($produits_strip, $avis_stats);
        $produits_top_panneau = marketplace_apply_avis_stats($produits_top_panneau, $avis_stats);
        $produits_new_panneau = marketplace_apply_avis_stats($produits_new_panneau, $avis_stats);
        $produits_tous = marketplace_apply_avis_stats($produits_tous, $avis_stats);
    }
    ?>

    <main class="mp-main">

        <section class="mp-hero" aria-label="Affichage marketplace">
            <?php if (!empty($hero_affiches)): ?>
                <div class="mp-slider-wrap mp-hero-slider-wrap">
                    <div class="slider-area owl-carousel">
                        <?php foreach ($hero_affiches as $hero_index => $ha): ?>
                            <?php
                            $hero_img = trim(str_replace('\\', '/', (string) ($ha['image'] ?? '')));
                            $hero_rel = str_contains($hero_img, '/') ? $hero_img : 'marketplace_hero/' . $hero_img;
                            $hero_alt = htmlspecialchars((string) ($ha['alt_text'] ?? ''), ENT_QUOTES, 'UTF-8');
                            $hero_md = upload_image_url($hero_rel, 'md');
                            $hero_full = upload_image_url($hero_rel, 'original');
                            $hero_src = htmlspecialchars($hero_md, ENT_QUOTES, 'UTF-8');
                            // Variante « md » sur mobile, original sur grand écran / Retina — largeurs réelles des fichiers
                            $hero_w = static function (string $url): int {
                                $path = parse_url($url, PHP_URL_PATH) ?: '';
                                $pos = strpos($path, '/upload/');
                                $file = $pos === false ? '' : __DIR__ . substr($path, $pos);
                                $size = $file !== '' && is_file($file) ? @getimagesize($file) : false;
                                return $size ? (int) $size[0] : 0;
                            };
                            $hero_md_w = $hero_w($hero_md);
                            // Dimensions réelles : sur téléphone le cadre prend la proportion de l'affiche
                            $hero_md_file = (static function (string $url): string {
                                $path = parse_url($url, PHP_URL_PATH) ?: '';
                                $pos = strpos($path, '/upload/');
                                return $pos === false ? '' : __DIR__ . substr($path, $pos);
                            })($hero_md);
                            $hero_md_size = $hero_md_file !== '' && is_file($hero_md_file) ? @getimagesize($hero_md_file) : false;
                            $hero_full_w = $hero_w($hero_full);
                            $hero_srcset = ($hero_full !== $hero_md && $hero_md_w > 0 && $hero_full_w > $hero_md_w)
                                ? htmlspecialchars($hero_md . ' ' . $hero_md_w . 'w, ' . $hero_full . ' ' . $hero_full_w . 'w', ENT_QUOTES, 'UTF-8')
                                : '';
                            ?>
                            <div class="slider-item" style="--hero-bg: url('<?php echo $hero_src; ?>');">
                                <img src="<?php echo $hero_src; ?>" alt="<?php echo $hero_alt; ?>"
                                    <?php if ($hero_md_size): ?>width="<?php echo (int) $hero_md_size[0]; ?>" height="<?php echo (int) $hero_md_size[1]; ?>"<?php endif; ?>
                                    <?php if ($hero_srcset !== ''): ?>srcset="<?php echo $hero_srcset; ?>" sizes="(max-width: 1360px) 100vw, 1320px"<?php endif; ?>
                                    decoding="async"<?php echo $hero_index === 0 ? ' fetchpriority="high"' : ' fetchpriority="low"'; ?>>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php else: ?>
                <div class="mp-hero-placeholder" role="img" aria-label="Aucune bannière"></div>
            <?php endif; ?>
        </section>

        <?php if (!empty($mp_popular_cats)): ?>
            <section class="mp-popular-categories" aria-label="Catégories populaires">
                <div class="mp-popular-categories-inner">
                    <div class="mp-popular-categories-track" role="list">
                        <?php foreach ($mp_popular_cats as $prow): ?>
                            <?php
                            $plabel = trim((string) ($prow['nom'] ?? ''));
                            if ($plabel === '') {
                                continue;
                            }
                            $pic_class = function_exists('categorie_fa_icon_class')
                                ? categorie_fa_icon_class($prow)
                                : 'fa-solid fa-layer-group';
                            $pop_img = function_exists('categorie_image_public_path')
                                ? categorie_image_public_path($prow)
                                : null;
                            $has_pop_img = is_string($pop_img) && $pop_img !== '';
                            $pid = (int) ($prow['id'] ?? 0);
                            if ($mp_nav_is_generale) {
                                $phref = $pid > 0 && function_exists('nav_categorie_generale_href')
                                    ? nav_categorie_generale_href($pid)
                                    : ('produits.php?recherche=' . rawurlencode($plabel));
                            } else {
                                $phref = $pid > 0 && function_exists('nav_categorie_href')
                                    ? nav_categorie_href($pid)
                                    : 'produits.php';
                            }
                            ?>
                            <a class="mp-pop-cat-item" role="listitem"
                                href="<?php echo htmlspecialchars($phref, ENT_QUOTES, 'UTF-8'); ?>"
                                title="<?php echo htmlspecialchars($plabel, ENT_QUOTES, 'UTF-8'); ?>">
                                <span class="mp-pop-cat-icon<?php echo $has_pop_img ? ' mp-pop-cat-icon--photo' : ''; ?>"
                                    aria-hidden="true">
                                    <?php if ($has_pop_img): ?>
                                        <img src="<?php echo htmlspecialchars(upload_image_url_from_src($pop_img, 'sm'), ENT_QUOTES, 'UTF-8'); ?>"
                                            alt="" loading="lazy" decoding="async">
                                    <?php else: ?>
                                        <i class="<?php echo htmlspecialchars($pic_class, ENT_QUOTES, 'UTF-8'); ?>"></i>
                                    <?php endif; ?>
                                </span>
                                <?php
                                // Libellés saisis tout en majuscules : affichage en casse phrase, homogène avec les autres tuiles
                                $plabel_display = ($plabel === mb_strtoupper($plabel, 'UTF-8'))
                                    ? mb_strtoupper(mb_substr($plabel, 0, 1, 'UTF-8'), 'UTF-8') . mb_strtolower(mb_substr($plabel, 1, null, 'UTF-8'), 'UTF-8')
                                    : $plabel;
                                // 10 lettres maximum (nom complet dans l'infobulle du lien)
                                if (mb_strlen($plabel_display, 'UTF-8') > 10) {
                                    $plabel_display = rtrim(mb_substr($plabel_display, 0, 10, 'UTF-8'), " \t&,-") . '…';
                                }
                                ?>
                                <span class="mp-pop-cat-label"><?php echo htmlspecialchars($plabel_display); ?></span>
                            </a>
                        <?php endforeach; ?>
                        <button type="button" class="mp-pop-cat-item mp-pop-cat-item--all" role="listitem"
                            title="Voir toutes les catégories"
                            onclick="if(typeof window.openBoutiqueNavSidebar==='function'){window.openBoutiqueNavSidebar();}">
                            <span class="mp-pop-cat-icon" aria-hidden="true">
                                <span class="mp-pop-grid-dots">
                                    <span></span><span></span><span></span><span></span>
                                </span>
                            </span>
                            <span class="mp-pop-cat-label">Voir tout</span>
                        </button>
                    </div>
                </div>
            </section>
        <?php endif; ?>

        <div class="mp-shell">
            <section class="mp-showcase" aria-label="Tendances et sélections">
                <div class="mp-showcase-inner mp-showcase-inner--no-nav">
                    <div class="mp-showcase-center">
                        <div class="mp-showcase-center-top">
                            <div>
                                <h2><?php echo $mp_home_personalized ? 'Sélection pour vous' : 'Recherches fréquentes'; ?></h2>
                            </div>
                            <div class="mp-trend-nav">
                                <button type="button" class="mp-trend-prev" aria-label="Faire défiler vers la gauche">
                                    <i class="fas fa-chevron-left"></i>
                                </button>
                                <button type="button" class="mp-trend-next" aria-label="Faire défiler vers la droite">
                                    <i class="fas fa-chevron-right"></i>
                                </button>
                            </div>
                        </div>
                        <div class="mp-trend-scroll" id="mpTrendScroll">
                            <?php if (empty($produits_showcase_center)): ?>
                                <p class="mp-empty" style="min-width:100%;margin:0;">Aucun produit à afficher.</p>
                            <?php else: ?>
                                <?php foreach ($produits_showcase_center as $produit): ?>
                                    <?php
                                    $tid = (int) ($produit['id'] ?? 0);
                                    if ($tid <= 0) {
                                        continue;
                                    }
                                    $tnom = trim((string) ($produit['nom'] ?? ''));
                                    if ($tnom === '') {
                                        $tnom = 'Produit';
                                    }
                                    $showcase_is_featured = $mp_home_personalized && $mp_showcase_featured_id > 0 && $tid === $mp_showcase_featured_id;
                                    if ($showcase_is_featured) {
                                        $showcase_label = 'Pour vous';
                                    } elseif ($mp_home_personalized) {
                                        $showcase_label = 'Suggestion';
                                    } else {
                                        $showcase_label = 'Recherché';
                                    }
                                    ?>
                                    <div class="mp-trend-card<?php echo $showcase_is_featured ? ' mp-trend-card--featured' : ''; ?>">
                                        <?php /* Étiquette seulement si elle apporte une info (personnalisation) : « Recherché » répétait le titre */ ?>
                                        <?php if ($showcase_label !== 'Recherché'): ?>
                                        <span class="mp-trend-label"><?php echo htmlspecialchars($showcase_label, ENT_QUOTES, 'UTF-8'); ?></span>
                                        <?php endif; ?>
                                        <a class="mp-trend-img-link" href="produit.php?id=<?php echo $tid; ?>&amp;mp_ref=home_trend">
                                            <img src="<?php echo htmlspecialchars(upload_image_url($produit['image_principale'] ?? '', 'sm')); ?>"
                                                alt="<?php echo htmlspecialchars($tnom); ?>" loading="lazy"
                                                onerror="this.src='/image/produit1.jpg'">
                                        </a>
                                        <span class="mp-trend-sub"><?php echo htmlspecialchars($tnom); ?></span>
                                        <?php if (!empty($produit['avis_count'])): ?>
                                            <?php
                                            $note = (float) ($produit['avis_moyenne'] ?? 0);
                                            $count = (int) ($produit['avis_count'] ?? 0);
                                            $size = 'sm';
                                            require __DIR__ . '/includes/partials/product_rating_stars.php';
                                            ?>
                                        <?php endif; ?>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>

                    <aside class="mp-showcase-boutiques mp-shops" aria-labelledby="mp-bt-title">
                        <header class="mp-shops__head">
                            <h2 class="mp-shops__title" id="mp-bt-title">Boutiques partenaires</h2>
                            <a class="mp-shops__more" href="/boutiques.php">
                                Voir plus <i class="fas fa-chevron-right" aria-hidden="true"></i>
                            </a>
                        </header>
                        <?php if (empty($boutiques_accueil)): ?>
                            <div class="mp-shops__empty">
                                <i class="fas fa-store" aria-hidden="true"></i>
                                <span>Les boutiques vendeurs apparaîtront ici.</span>
                            </div>
                        <?php else: ?>
                            <?php
                            if (!function_exists('boutique_vitrine_entry_href')) {
                                require_once __DIR__ . '/includes/marketplace_helpers.php';
                            }
                            ?>
                            <ul class="mp-shops__list">
                                <?php foreach ($boutiques_accueil as $shop):
                                    $shop_slug = trim((string) ($shop['boutique_slug'] ?? ''));
                                    if ($shop_slug === '') {
                                        continue;
                                    }
                                    $shop_nom = trim((string) ($shop['boutique_nom'] ?? '')) ?: 'Boutique';
                                    $shop_logo = trim(str_replace('\\', '/', (string) ($shop['boutique_logo'] ?? '')));
                                    $shop_certif = !empty($shop['certification_niveau']);
                                    $shop_theme = function_exists('marketplace_boutique_card_theme')
                                        ? marketplace_boutique_card_theme($shop) : ['main' => '#3564a6'];
                                    $shop_initiale = mb_strtoupper(mb_substr(preg_replace('/[^\p{L}\p{N}]/u', '', $shop_nom) ?: 'B', 0, 1));
                                    ?>
                                    <li>
                                        <a class="mp-shop" href="<?php echo htmlspecialchars(boutique_vitrine_entry_href($shop_slug), ENT_QUOTES, 'UTF-8'); ?>"
                                            style="--shop-color: <?php echo htmlspecialchars((string) $shop_theme['main'], ENT_QUOTES, 'UTF-8'); ?>">
                                            <span class="mp-shop__cover" aria-hidden="true"></span>
                                            <span class="mp-shop__logo" aria-hidden="true" data-initiale="<?php echo htmlspecialchars($shop_initiale, ENT_QUOTES, 'UTF-8'); ?>">
                                                <?php if ($shop_logo !== ''): ?>
                                                    <img src="<?php echo htmlspecialchars('/upload/' . $shop_logo, ENT_QUOTES, 'UTF-8'); ?>"
                                                        alt="" width="64" height="64" loading="lazy" decoding="async" onerror="this.remove();">
                                                <?php endif; ?>
                                            </span>
                                            <span class="mp-shop__name">
                                                <span class="mp-shop__name-text"><?php echo htmlspecialchars($shop_nom, ENT_QUOTES, 'UTF-8'); ?></span>
                                                <?php if ($shop_certif): ?>
                                                    <i class="fas fa-circle-check mp-shop__certif" title="Boutique certifiée" aria-label="Boutique certifiée"></i>
                                                <?php endif; ?>
                                            </span>
                                        </a>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        <?php endif; ?>
                    </aside>
                </div>
            </section>
        </div>

        <div class="mp-shell">
            <section class="mp-top" aria-labelledby="mp-top-title">
                <header class="mp-top__head">
                    <h2 class="mp-top__title" id="mp-top-title">
                        <span class="mp-top__trophy" aria-hidden="true"><i class="fas fa-trophy"></i></span>
                        Top des ventes
                    </h2>
                    <div class="mp-top__actions">
                        <button type="button" class="mp-top__nav" data-top-scroll="-1" aria-label="Précédents"><i class="fas fa-chevron-left" aria-hidden="true"></i></button>
                        <button type="button" class="mp-top__nav" data-top-scroll="1" aria-label="Suivants"><i class="fas fa-chevron-right" aria-hidden="true"></i></button>
                        <a class="mp-top__all" href="top-ventes.php">Tout voir <i class="fas fa-arrow-right" aria-hidden="true"></i></a>
                    </div>
                </header>
                <div class="mp-top__track" id="mpStripScroll">
                    <?php $top_rang = 0; ?>
                    <?php foreach ($produits_strip as $sproduit): ?>
                        <?php
                        $sid = (int) ($sproduit['id'] ?? 0);
                        if ($sid <= 0) {
                            continue;
                        }
                        $top_rang++;
                        $s_promo = !empty($sproduit['prix_promotion']) && $sproduit['prix_promotion'] < $sproduit['prix'];
                        $spx = $s_promo ? (float) $sproduit['prix_promotion'] : (float) ($sproduit['prix'] ?? 0);
                        $snom = (string) ($sproduit['nom'] ?? 'Produit');
                        ?>
                        <a class="mp-top-card mp-top-card--<?php echo $top_rang; ?>" href="produit.php?id=<?php echo $sid; ?>&amp;mp_ref=home_strip">
                            <span class="mp-top-card__rank" aria-label="Numéro <?php echo $top_rang; ?>"><?php echo $top_rang; ?></span>
                            <div class="mp-top-card__img">
                                <img src="<?php echo htmlspecialchars(upload_image_url($sproduit['image_principale'] ?? '', 'sm')); ?>"
                                    alt="<?php echo htmlspecialchars($snom); ?>" loading="lazy"
                                    onerror="this.src='/image/produit1.jpg'">
                            </div>
                            <div class="mp-top-card__body">
                                <p class="mp-top-card__title"><?php echo htmlspecialchars($snom); ?></p>
                                <?php if (!empty($sproduit['avis_count'])): ?>
                                    <?php
                                    $note = (float) ($sproduit['avis_moyenne'] ?? 0);
                                    $count = (int) ($sproduit['avis_count'] ?? 0);
                                    $size = 'sm';
                                    require __DIR__ . '/includes/partials/product_rating_stars.php';
                                    ?>
                                <?php endif; ?>
                                <p class="mp-top-card__price">
                                    <strong><?php echo number_format($spx, 0, ',', ' '); ?> FCFA</strong>
                                    <?php if ($s_promo): ?><s><?php echo number_format((float) $sproduit['prix'], 0, ',', ' '); ?></s><?php endif; ?>
                                </p>
                            </div>
                        </a>
                    <?php endforeach; ?>
                </div>
                <script>
                (function () {
                    var track = document.getElementById('mpStripScroll');
                    if (!track) return;
                    document.querySelectorAll('[data-top-scroll]').forEach(function (btn) {
                        btn.addEventListener('click', function () {
                            track.scrollBy({ left: parseInt(btn.getAttribute('data-top-scroll'), 10) * track.clientWidth * 0.8, behavior: 'smooth' });
                        });
                    });
                })();
                </script>
            </section>
        </div>

        <div class="mp-shell">

            <?php if (!empty($logos_carousel)): ?>
                <div class="mp-logos-wrap">
                    <section class="marques-section logos-section" data-aos="fade-up" data-aos-duration="600">
                        <div class="marques-container">
                            <button type="button" class="marques-nav marques-nav-prev logos-nav-prev"
                                aria-label="Logos précédents">
                                <i class="fas fa-chevron-left"></i>
                            </button>
                            <div class="marques-carousel owl-carousel logos-owl">
                                <?php foreach ($logos_carousel as $logo): ?>
                                    <?php
                                    $logo_path = '/image/produit1.jpg';
                                    if (!empty($logo['image'])) {
                                        $file_path = __DIR__ . '/upload/' . $logo['image'];
                                        if (file_exists($file_path)) {
                                            $logo_path = upload_image_url((string) $logo['image'], 'sm');
                                        }
                                    }
                                    ?>
                                    <div class="marque-item marque-item-logo">
                                        <div class="marque-logo-wrap">
                                            <img src="<?php echo $logo_path; ?>" alt="Logo partenaire" loading="lazy"
                                                decoding="async"
                                                onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                                            <span class="marque-fallback" style="display: none;"><i
                                                    class="fas fa-image"></i></span>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                            <button type="button" class="marques-nav marques-nav-next logos-nav-next"
                                aria-label="Logos suivants">
                                <i class="fas fa-chevron-right"></i>
                            </button>
                        </div>
                    </section>
                </div>
            <?php endif; ?>

            <section class="mp-pair" aria-label="Classements et nouveautés">
                <div class="mp-pair-grid">
                    <article class="mp-panel">
                        <header class="mp-panel-head">
                            <div>
                                <h2>Les plus consultés</h2>
                            </div>
                            <a class="mp-panel-more" href="plus-consultes.php">Voir tout <i class="fas fa-arrow-right" aria-hidden="true"></i></a>
                        </header>
                        <div class="mp-panel-products">
                            <?php if (empty($produits_top_panneau)): ?>
                                <p class="mp-empty" style="grid-column:1/-1;">Aucun produit à mettre en avant pour le
                                    moment.</p>
                            <?php else: ?>
                                <?php
                                foreach ($produits_top_panneau as $produit) {
                                    $return_url = $return_url_mp;
                                    require $partial_top;
                                }
                                ?>
                            <?php endif; ?>
                        </div>
                    </article>
                    <article class="mp-panel">
                        <header class="mp-panel-head">
                            <div>
                                <h2>Nouveautés</h2>
                            </div>
                            <a class="mp-panel-more" href="nouveautes.php">Voir tout <i class="fas fa-arrow-right" aria-hidden="true"></i></a>
                        </header>
                        <div class="mp-panel-products">
                            <?php if (empty($produits_new_panneau)): ?>
                                <p class="mp-empty" style="grid-column:1/-1;">Pas de nouveautés pour le moment.</p>
                            <?php else: ?>
                                <?php
                                foreach ($produits_new_panneau as $produit) {
                                    $return_url = $return_url_mp;
                                    require $partial_newc;
                                }
                                ?>
                            <?php endif; ?>
                        </div>
                    </article>
                </div>
            </section>


            <section class="mp-block" aria-labelledby="mp-all-heading">
                <header class="mp-block-head">
                    <h2 id="mp-all-heading">Nos produits</h2>
                    <?php if ($total_produits > 0): ?>
                        <a class="mp-block-more" href="produits.php">Catalogue (<?php echo (int) $total_produits; ?>)</a>
                    <?php endif; ?>
                </header>
                <div class="mp-grid" id="produits-container"
                    data-seed="<?php echo (int) ($seed_tous ?? 1); ?>"
                    data-offset="0"
                    data-endpoint="<?php echo htmlspecialchars(app_url('/api/home_produits_html.php'), ENT_QUOTES, 'UTF-8'); ?>">
                    <?php if (empty($produits_tous)): ?>
                        <p class="mp-empty">Aucun produit publié pour le moment.</p>
                    <?php else: ?>
                        <?php
                        foreach ($produits_tous as $mp_i => $produit) {
                            $return_url = $return_url_mp;
                            require $card_partial;
                            if ($mp_i === 3) {
                                /* Rayons après la 1re ligne ; le script recale selon le nombre de colonnes */
                                require __DIR__ . '/includes/partials/home_quad_banners.php';
                            }
                        }
                        ?>
                    <?php endif; ?>
                </div>
                <?php if (!empty($produits_tous)): ?>
                    <?php require __DIR__ . '/includes/partials/home_duo_banners.php'; ?>
                    <script>
                    (function () {
                        /* Quad (rayons) sous la 1re ligne ; Duo (offres) sous la 3e ligne */
                        var grid = document.getElementById('produits-container');
                        var duo = document.getElementById('mpDuo');
                        var quad = document.getElementById('mpQuad');
                        if (!grid) return;

                        function colsAndCards() {
                            var cols = getComputedStyle(grid).gridTemplateColumns.split(' ').filter(Boolean).length || 1;
                            var cards = grid.querySelectorAll(':scope > .mp-card');
                            return { cols: cols, cards: cards };
                        }

                        function placeQuad() {
                            if (!quad) return;
                            var info = colsAndCards();
                            if (!info.cards.length) return;
                            var after = info.cards[Math.min(info.cols, info.cards.length) - 1];
                            if (after && after.nextElementSibling !== quad) after.after(quad);
                        }

                        function placeDuo() {
                            if (!duo) return;
                            var info = colsAndCards();
                            var n = info.cols * 3;
                            if (info.cards.length < n) return;
                            var after = info.cards[n - 1];
                            if (after.nextElementSibling !== duo) after.after(duo);
                        }

                        placeQuad();
                        placeDuo();
                        new MutationObserver(function () { placeDuo(); }).observe(grid, { childList: true });
                        var t;
                        window.addEventListener('resize', function () {
                            clearTimeout(t);
                            t = setTimeout(function () { placeQuad(); placeDuo(); }, 150);
                        });
                    })();
                    </script>
                <?php endif; ?>
                <?php if (!empty($produits_tous) && $total_produits > count($produits_tous)): ?>
                    <div class="mp-infinite" id="mpInfinite" role="status" aria-label="Chargement des produits">
                        <span></span><span></span><span></span>
                    </div>
                    <noscript><p style="text-align:center"><a href="produits.php">Voir tous les produits</a></p></noscript>
                    <script>
                    (function () {
                        /* « Nos produits » : le lot suivant se charge tout seul en approchant du bas */
                        var grid = document.getElementById('produits-container');
                        var sentinel = document.getElementById('mpInfinite');
                        if (!grid || !sentinel || !('IntersectionObserver' in window)) return;
                        var offset = parseInt(grid.getAttribute('data-offset'), 10) || 0;
                        var seed = grid.getAttribute('data-seed');
                        var endpoint = grid.getAttribute('data-endpoint');
                        var busy = false, done = false, fails = 0;

                        function finish() {
                            done = true;
                            observer.disconnect();
                            sentinel.hidden = true;
                        }

                        function load() {
                            if (busy || done) return;
                            busy = true;
                            sentinel.classList.add('is-loading');
                            fetch(endpoint + '?offset=' + offset + '&seed=' + encodeURIComponent(seed), { credentials: 'same-origin' })
                                .then(function (r) { if (!r.ok) throw new Error(r.status); return r.json(); })
                                .then(function (data) {
                                    fails = 0;
                                    if (data.html) grid.insertAdjacentHTML('beforeend', data.html);
                                    offset = data.next_offset;
                                    if (data.done) finish();
                                })
                                .catch(function () {
                                    if (++fails >= 3) finish();
                                })
                                .then(function () {
                                    busy = false;
                                    sentinel.classList.remove('is-loading');
                                    /* Écran encore vide en bas : on enchaîne le lot suivant */
                                    if (!done && sentinel.getBoundingClientRect().top < window.innerHeight + 600) {
                                        setTimeout(load, 150);
                                    }
                                });
                        }

                        var observer = new IntersectionObserver(function (entries) {
                            if (entries[0].isIntersecting) load();
                        }, { rootMargin: '0px 0px 600px 0px' });
                        observer.observe(sentinel);
                    })();
                    </script>
                <?php endif; ?>
            </section>

        </div>
    </main>
    <?php include('footer.php') ?>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js" crossorigin="anonymous"
        referrerpolicy="no-referrer" defer></script>
    <script>
        (function () {
            function finishAos() {
                document.documentElement.classList.remove('aos-not-ready');
            }

            function runAos() {
                if (typeof AOS === 'undefined') {
                    finishAos();
                    return;
                }
                AOS.init({
                    duration: 800,
                    once: true,
                    offset: 24,
                    disable: function () {
                        if (window.__COLOBANES_NATIVE_APP === true ||
                            document.documentElement.classList.contains('is-native-app')) {
                            return true;
                        }
                        return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
                    }
                });
                requestAnimationFrame(function () {
                    requestAnimationFrame(finishAos);
                });
            }
            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', runAos);
            } else {
                runAos();
            }
        })();
    </script>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            var el = document.getElementById('mpTrendScroll');
            var prev = document.querySelector('.mp-showcase-center .mp-trend-prev');
            var next = document.querySelector('.mp-showcase-center .mp-trend-next');
            if (!el) return;
            function showcaseScrollStep() {
                var card = el.querySelector('.mp-trend-card');
                if (!card) {
                    return 220;
                }
                var gap = 12;
                var style = window.getComputedStyle(el);
                var g = parseFloat(style.columnGap || style.gap) || gap;
                return card.getBoundingClientRect().width + g;
            }
            if (prev) {
                prev.addEventListener('click', function () {
                    el.scrollBy({
                        left: -showcaseScrollStep() * 4,
                        behavior: 'smooth'
                    });
                });
            }
            if (next) {
                next.addEventListener('click', function () {
                    el.scrollBy({
                        left: showcaseScrollStep() * 4,
                        behavior: 'smooth'
                    });
                });
            }
        });
    </script>
    <?php /* Si le carrousel ne charge pas, la première affiche reste visible (css/mp-hero-slider.css) */ ?>
    <script id="mpOwlScript" src="https://cdnjs.cloudflare.com/ajax/libs/OwlCarousel2/2.3.4/owl.carousel.min.js" defer></script>

    <script>
        /* Carrousels (affiche d'accueil, logos). Si jQuery n'a pas pu être chargé, on attend le chargement de secours. */
        function mpInitCarousels() {
            if (typeof window.jQuery === 'undefined' || !window.jQuery.fn || !window.jQuery.fn.owlCarousel) {
                return false;
            }
            window.jQuery(function ($) {
                if ($('.mp-hero-slider-wrap .slider-area').length && $('.mp-hero-slider-wrap .slider-item')
                    .length) {
                    var $mpHeroSlider = $('.mp-hero-slider-wrap .slider-area');
                    var mpHeroSlideCount = $mpHeroSlider.children('.slider-item').length;
                    var mpHeroCarouselEnabled = mpHeroSlideCount > 1;
                    /* Téléphone : hauteur du cadre = proportion de l'affiche affichée (css/mp-hero-slider.css) */
                    var mpHeroFluid = window.matchMedia && window.matchMedia('(max-width: 767px)').matches;

                    $mpHeroSlider.owlCarousel({
                        items: 1,
                        slideBy: 1,
                        loop: mpHeroCarouselEnabled,
                        dots: false,
                        nav: false,
                        mouseDrag: false,
                        touchDrag: false,
                        pullDrag: false,
                        freeDrag: false,
                        autoplay: mpHeroCarouselEnabled,
                        /* 7 s par affiche (le temps de lire), fondu doux d'1 s */
                        autoplayTimeout: 7000,
                        autoplayHoverPause: true,
                        autoplaySpeed: 1000,
                        smartSpeed: 1000,
                        /* Seule l'affiche sortante s'efface (la suivante est déjà affichée dessous) : jamais de blanc */
                        animateOut: 'fadeOut',
                        stagePadding: 0,
                        autoHeight: mpHeroFluid,
                        navText: ['<i class="fa-solid fa-chevron-left"></i>',
                            '<i class="fa-solid fa-chevron-right"></i>'
                        ]
                    });

                    var refreshMpHeroSlider = function () {
                        $mpHeroSlider.trigger('refresh.owl.carousel');
                    };
                    var mpHeroResizeTimer;
                    $(window).on('resize', function () {
                        clearTimeout(mpHeroResizeTimer);
                        mpHeroResizeTimer = setTimeout(refreshMpHeroSlider, 150);
                    });
                    $('.mp-hero-slider-wrap .slider-item img').each(function () {
                        if (this.complete) {
                            refreshMpHeroSlider();
                        } else {
                            $(this).on('load', refreshMpHeroSlider);
                        }
                    });

                    if (mpHeroCarouselEnabled) {
                        $mpHeroSlider.trigger('play.owl.autoplay', [7000]);
                    }

                    if (window.ColobanesSkeleton) {
                        window.ColobanesSkeleton.refresh();
                        if (typeof window.ColobanesSkeleton.checkFinishAll === 'function') {
                            window.ColobanesSkeleton.checkFinishAll();
                        }
                    }
                }

                // Carrousel des logos partenaires
                if ($('.logos-owl').length && $('.logos-owl .marque-item').length) {
                    var logosCarousel = $('.logos-owl').owlCarousel({
                        items: 4,
                        loop: true,
                        dots: false,
                        nav: false,
                        margin: 28,
                        stagePadding: 15,
                        autoplay: true,
                        autoplayTimeout: 3000,
                        autoplayHoverPause: true,
                        smartSpeed: 500,
                        responsive: {
                            0: {
                                items: 2,
                                margin: 16
                            },
                            480: {
                                items: 3,
                                margin: 20
                            },
                            768: {
                                items: 4,
                                margin: 28
                            },
                            992: {
                                items: 5,
                                margin: 28
                            }
                        }
                    });
                    $('.logos-nav-prev').on('click', function () {
                        logosCarousel.trigger('prev.owl.carousel');
                    });
                    $('.logos-nav-next').on('click', function () {
                        logosCarousel.trigger('next.owl.carousel');
                    });
                }
            });
            return true;
        }

        (function () {
            var done = false;
            function tryInit() {
                if (!done && mpInitCarousels()) {
                    done = true;
                }
            }
            document.addEventListener('DOMContentLoaded', tryInit);
            /* jQuery de secours arrivé après coup : le carrousel n'a pas pu s'installer, on le recharge puis on initialise */
            document.addEventListener('colobanes:jquery-ready', function () {
                if (window.jQuery.fn.owlCarousel) {
                    tryInit();
                    return;
                }
                var s = document.createElement('script');
                s.src = document.getElementById('mpOwlScript').src;
                s.onload = tryInit;
                document.body.appendChild(s);
            }, { once: true });
        })();
    </script>

</body>

</html>