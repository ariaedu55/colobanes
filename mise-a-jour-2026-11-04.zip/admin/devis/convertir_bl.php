<?php
/**
 * Conversion devis → BL (POST + jeton CSRF)
 */
require_once __DIR__ . '/../includes/require_admin_session.php';


require_once __DIR__ . '/../includes/require_access.php';


require_once __DIR__ . '/../../includes/admin_permissions.php';
if (!admin_can_devis_bl()) {
    header('Location: ../dashboard.php');
    exit;
}

/* Création de document : POST + jeton CSRF admin uniquement (plus de GET depuis un lien) */
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !admin_csrf_valid($_POST['csrf_token'] ?? '')) {
    header('Location: index.php');
    exit;
}

$devis_id = isset($_POST['id']) ? (int) $_POST['id'] : 0;
if ($devis_id <= 0) {
    header('Location: index.php');
    exit;
}

require_once __DIR__ . '/../../models/model_bl.php';

$res = create_bl_from_devis($devis_id, (int) $_SESSION['admin_id']);
if (!empty($res['success'])) {
    $_SESSION['success_message'] = 'Bon de livraison ' . ($res['numero_bl'] ?? '') . ' créé à partir du devis. Vous pouvez le compléter ou le valider.';
    header('Location: bl_voir.php?id=' . (int) $res['bl_id']);
    exit;
}

$_SESSION['error_devis'] = $res['message'] ?? 'Conversion impossible.';
header('Location: index.php');
exit;
