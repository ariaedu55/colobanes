<?php
/**
 * Page de liste des devis (Admin)
 */
require_once __DIR__ . '/../includes/require_admin_session.php';



require_once __DIR__ . '/../includes/require_access.php';

require_once __DIR__ . '/../../includes/admin_permissions.php';
if (!admin_can_devis_bl()) {
    header('Location: ../dashboard.php');
    exit;
}

require_once __DIR__ . '/../../models/model_devis.php';
require_once __DIR__ . '/../../models/model_zones_livraison.php';
require_once __DIR__ . '/../../models/model_bl.php';

if (empty($_SESSION['admin_csrf'])) {
    $_SESSION['admin_csrf'] = bin2hex(random_bytes(32));
}

$devis_list = get_all_devis();
$vf_zones = admin_vendeur_filter_id();
$zones_livraison = get_all_zones_livraison('actif', $vf_zones !== null ? $vf_zones : false);
$bl_tables_ok = bl_tables_available();
$bl_clients_list = $bl_tables_ok ? get_clients_b2b_avec_bl() : [];

$error_devis = $_SESSION['error_devis'] ?? null;
if (isset($_SESSION['error_devis'])) {
    unset($_SESSION['error_devis']);
}
$bl_erreur = $_SESSION['bl_erreur'] ?? null;
if (isset($_SESSION['bl_erreur'])) {
    unset($_SESSION['bl_erreur']);
}

$show_modal_devis = isset($_GET['modal']) && $_GET['modal'] === 'devis';
$show_modal_bl = isset($_GET['modal']) && $_GET['modal'] === 'bl';
$active_tab = (isset($_GET['tab']) && $_GET['tab'] === 'bl') ? 'bl' : 'devis';

$devis_erreur = $_SESSION['devis_erreur'] ?? null;
$devis_post = $_SESSION['devis_post'] ?? null;
if (isset($_SESSION['devis_erreur'])) {
    unset($_SESSION['devis_erreur']);
}
if (isset($_SESSION['devis_post'])) {
    unset($_SESSION['devis_post']);
}

$bl_post = $_SESSION['bl_post'] ?? null;
if (isset($_SESSION['bl_post'])) {
    unset($_SESSION['bl_post']);
}
$bl_modal_err = $bl_erreur;
if ($show_modal_bl && $bl_modal_err) {
    $bl_erreur = null;
}

/** Valeurs re-affichées dans le modal BL (mêmes clés que le devis + date_bl / statut) */
$bp = is_array($bl_post) ? $bl_post : [];
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <?php include __DIR__ . '/../../includes/favicon.php'; ?>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Devis &amp; BL — Administration</title>
    <?php require_once __DIR__ . '/../../includes/asset_version.php'; ?>
    <?php require_once dirname(__DIR__, 2) . '/includes/ui_font_awesome.php'; ?>
    <link rel="stylesheet" href="/css/admin-dashboard.css<?php echo asset_version_query(); ?>">
</head>
<body>
    <?php include '../includes/nav.php'; ?>

    <div class="content-header">
        <h1><i class="fas fa-handshake"></i> Devis &amp; bons de livraison</h1>
    </div>

    <?php if (isset($_SESSION['success_message'])): ?>
        <div class="message success">
            <i class="fas fa-check-circle"></i>
            <span><?php echo htmlspecialchars($_SESSION['success_message']); unset($_SESSION['success_message']); ?></span>
        </div>
    <?php endif; ?>

    <?php if ($error_devis): ?>
        <div class="message error">
            <i class="fas fa-exclamation-circle"></i>
            <span><?php echo htmlspecialchars($error_devis); ?></span>
        </div>
    <?php endif; ?>

    <?php if (!empty($bl_erreur)): ?>
        <div class="message error">
            <i class="fas fa-exclamation-circle"></i>
            <span><?php echo htmlspecialchars($bl_erreur); ?></span>
        </div>
    <?php endif; ?>

    <?php
    $tab_devis_active = $active_tab === 'devis';
    $tab_bl_active = $active_tab === 'bl';
    ?>
    <section class="content-section">
        <div class="section-header section-header--tabs">
            <div class="admin-devis-bl-tabs" role="tablist" aria-label="Devis ou bons de livraison">
                <button type="button" class="admin-tab <?php echo $tab_devis_active ? 'is-active' : ''; ?>" id="tab-btn-devis" role="tab" aria-selected="<?php echo $tab_devis_active ? 'true' : 'false'; ?>" aria-controls="panel-devis" data-tab="devis">
                    <i class="fas fa-file-invoice"></i> Devis (<?php echo count($devis_list); ?>)
                </button>
                <button type="button" class="admin-tab <?php echo $tab_bl_active ? 'is-active' : ''; ?>" id="tab-btn-bl" role="tab" aria-selected="<?php echo $tab_bl_active ? 'true' : 'false'; ?>" aria-controls="panel-bl" data-tab="bl" <?php echo !$bl_tables_ok ? 'disabled title="Migration B2B requise"' : ''; ?>>
                    <i class="fas fa-truck-loading"></i> Bons de livraison (<?php echo $bl_tables_ok ? count($bl_clients_list) : 0; ?>)
                </button>
            </div>
        </div>

        <div id="panel-devis" class="tab-panel-devis-bl <?php echo $tab_devis_active ? 'is-active' : ''; ?>" role="tabpanel" aria-labelledby="tab-btn-devis" <?php echo $tab_devis_active ? '' : 'hidden'; ?>>
        <div class="admin-devis-bl-panel-actions">
            <button type="button" class="btn-primary" id="btn-nouveau-devis" aria-label="Créer un devis">
                <i class="fas fa-plus-circle"></i> Nouveau devis
            </button>
        </div>
        <?php if (empty($devis_list)): ?>
            <div class="empty-state">
                <i class="fas fa-file-invoice"></i>
                <h3>Aucun devis</h3>
                <p>Cliquez sur « Nouveau devis » pour créer votre premier devis.</p>
            </div>
        <?php else: ?>
            <div class="commandes-grid">
                <?php foreach ($devis_list as $d): ?>
                    <?php
                    $devis_id_row = (int) $d['id'];
                    $is_brouillon = ($d['statut'] ?? '') === 'brouillon';
                    ?>
                    <div class="commande-item">
                        <div class="commande-header">
                            <div class="commande-info">
                                <h3>Devis #<?php echo htmlspecialchars($d['numero_devis']); ?></h3>
                                <p>
                                    <strong>Client:</strong> <?php echo htmlspecialchars(trim($d['client_prenom'] . ' ' . $d['client_nom'])); ?><br>
                                    <span class="client-email"><?php echo !empty($d['client_email']) ? htmlspecialchars($d['client_email']) : '—'; ?></span>
                                </p>
                                <p class="commande-date">Date: <?php echo date('d/m/Y à H:i', strtotime($d['date_creation'])); ?></p>
                            </div>
                            <span class="commande-statut statut-<?php echo htmlspecialchars($d['statut']); ?>">
                                <?php echo ucfirst($d['statut']); ?>
                            </span>
                        </div>
                        <div class="commande-details">
                            <div class="detail-item">
                                <label>Montant total</label>
                                <div class="value"><?php echo number_format($d['montant_total'], 0, ',', ' '); ?> FCFA</div>
                            </div>
                            <div class="detail-item">
                                <label>Adresse</label>
                                <div class="value small">
                                    <?php
                                    $adr_show = $d['adresse_livraison'] ?? '';
                                    $adr_snip = function_exists('mb_substr') ? mb_substr($adr_show, 0, 48) : substr($adr_show, 0, 48);
                                    echo htmlspecialchars($adr_snip);
                                    echo (function_exists('mb_strlen') ? mb_strlen($adr_show) : strlen($adr_show)) > 48 ? '…' : '';
                                    ?>
                                </div>
                            </div>
                            <div class="detail-item">
                                <label>Téléphone</label>
                                <div class="value"><?php echo htmlspecialchars($d['client_telephone']); ?></div>
                            </div>
                        </div>
                        <div class="commande-actions-devis" style="display:flex; flex-wrap:wrap; gap:8px; margin-top:12px; align-items:center;">
                            <a href="details.php?id=<?php echo $devis_id_row; ?>" class="btn-view"><i class="fas fa-eye"></i> Voir</a>
                            <?php if ($is_brouillon): ?>
                                <a href="modifier.php?id=<?php echo $devis_id_row; ?>" class="btn-secondary"><i class="fas fa-edit"></i> Modifier</a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
        </div>

        <div id="panel-bl" class="tab-panel-devis-bl <?php echo $tab_bl_active ? 'is-active' : ''; ?>" role="tabpanel" aria-labelledby="tab-btn-bl" <?php echo $tab_bl_active ? '' : 'hidden'; ?>>
        <?php if (!$bl_tables_ok): ?>
            <p class="message error" style="margin-bottom:16px;"><i class="fas fa-database"></i> Tables BL absentes : exécutez la migration <code>migrations/migration_admin_b2b_structure.sql</code>.</p>
        <?php else: ?>
        <div class="admin-devis-bl-panel-actions">
            <button type="button" class="btn-secondary" id="btn-nouveau-bl" aria-label="Créer un bon de livraison">
                <i class="fas fa-truck-loading"></i> Nouveau BL
            </button>
        </div>
        <?php if (empty($bl_clients_list)): ?>
            <div class="bl-empty-state" role="status">
                <div class="bl-empty-state__visual" aria-hidden="true">
                    <span class="bl-empty-state__ring"></span>
                    <i class="fas fa-truck-loading"></i>
                </div>
                <h3 class="bl-empty-state__title">Aucun contact avec bon de livraison</h3>
                <p class="bl-empty-state__text">Créez un premier BL avec « Nouveau BL » : le client professionnel apparaîtra ici pour un suivi rapide.</p>
            </div>
        <?php else: ?>
            <?php
            $bl_nb_contacts = count($bl_clients_list);
            ?>
            <div class="bl-tab-surface">
                <header class="bl-contacts-hero">
                    <div class="bl-contacts-hero__icon-wrap" aria-hidden="true">
                        <i class="fas fa-people-group"></i>
                    </div>
                    <div class="bl-contacts-hero__copy">
                        <h2 class="bl-contacts-hero__title">Contacts &amp; livraisons B2B</h2>
                        <p class="bl-contacts-hero__lead">Clients professionnels ayant au moins un bon de livraison. Accédez à l’historique complet par entreprise.</p>
                    </div>
                    <div class="bl-contacts-hero__stat" title="Nombre de contacts listés">
                        <span class="bl-contacts-hero__stat-num"><?php echo (int) $bl_nb_contacts; ?></span>
                        <span class="bl-contacts-hero__stat-label">contact<?php echo $bl_nb_contacts > 1 ? 's' : ''; ?></span>
                    </div>
                </header>

                <div class="bl-contacts-grid" role="list">
                <?php foreach ($bl_clients_list as $cl): ?>
                    <?php
                    $cid = (int) $cl['id'];
                    $nb_bl = (int) ($cl['nb_bl'] ?? 0);
                    $contact_nom = trim(($cl['nom_contact'] ?? '') . ' ' . ($cl['prenom_contact'] ?? ''));
                    $rs = trim($cl['raison_sociale'] ?? '');
                    $initials = '?';
                    if ($rs !== '') {
                        $words = preg_split('/\s+/u', $rs, -1, PREG_SPLIT_NO_EMPTY);
                        if (count($words) >= 2) {
                            $initials = mb_strtoupper(
                                mb_substr($words[0], 0, 1) . mb_substr($words[1], 0, 1),
                                'UTF-8'
                            );
                        } else {
                            $initials = mb_strtoupper(mb_substr($rs, 0, min(2, mb_strlen($rs, 'UTF-8')), 'UTF-8'), 'UTF-8');
                        }
                    }
                    $adr_short = '';
                    if (!empty($cl['adresse'])) {
                        $adr_short = mb_substr($cl['adresse'], 0, 110);
                        if (mb_strlen($cl['adresse'], 'UTF-8') > 110) {
                            $adr_short .= '…';
                        }
                    }
                    $last_bl = !empty($cl['dernier_bl_date'])
                        ? date('d/m/Y · H:i', strtotime($cl['dernier_bl_date']))
                        : '—';
                    ?>
                    <article class="bl-contact-card" role="listitem">
                        <div class="bl-contact-card__inner">
                            <div class="bl-contact-card__head">
                                <div class="bl-contact-card__avatar" aria-hidden="true"><?php echo htmlspecialchars($initials); ?></div>
                                <div class="bl-contact-card__head-text">
                                    <h3 class="bl-contact-card__company"><?php echo htmlspecialchars($rs ?: '—'); ?></h3>
                                    <?php if ($contact_nom !== ''): ?>
                                        <p class="bl-contact-card__person">
                                            <i class="fas fa-user-tie" aria-hidden="true"></i>
                                            <?php echo htmlspecialchars($contact_nom); ?>
                                        </p>
                                    <?php endif; ?>
                                </div>
                                <span class="bl-contact-card__pill">
                                    <i class="fas fa-file-invoice" aria-hidden="true"></i>
                                    <?php echo $nb_bl; ?> BL
                                </span>
                            </div>

                            <ul class="bl-contact-card__meta">
                                <li class="bl-contact-card__meta-row">
                                    <span class="bl-contact-card__meta-ic" aria-hidden="true"><i class="fas fa-phone"></i></span>
                                    <span class="bl-contact-card__meta-val"><?php echo htmlspecialchars($cl['telephone'] ?? '—'); ?></span>
                                </li>
                                <li class="bl-contact-card__meta-row">
                                    <span class="bl-contact-card__meta-ic" aria-hidden="true"><i class="fas fa-envelope"></i></span>
                                    <span class="bl-contact-card__meta-val"><?php echo !empty($cl['email']) ? htmlspecialchars($cl['email']) : '—'; ?></span>
                                </li>
                                <?php if ($adr_short !== ''): ?>
                                <li class="bl-contact-card__meta-row bl-contact-card__meta-row--address">
                                    <span class="bl-contact-card__meta-ic" aria-hidden="true"><i class="fas fa-location-dot"></i></span>
                                    <span class="bl-contact-card__meta-val"><?php echo htmlspecialchars($adr_short); ?></span>
                                </li>
                                <?php endif; ?>
                            </ul>

                            <div class="bl-contact-card__foot">
                                <div class="bl-contact-card__last">
                                    <span class="bl-contact-card__last-label">Dernier BL</span>
                                    <?php if (!empty($cl['dernier_bl_date'])): ?>
                                        <time class="bl-contact-card__last-date" datetime="<?php echo htmlspecialchars(date('c', strtotime($cl['dernier_bl_date']))); ?>"><?php echo htmlspecialchars($last_bl); ?></time>
                                    <?php else: ?>
                                        <span class="bl-contact-card__last-date">—</span>
                                    <?php endif; ?>
                                </div>
                                <a href="bl_par_client.php?id=<?php echo $cid; ?>" class="bl-contact-card__cta">
                                    <span>Voir les bons de livraison</span>
                                    <i class="fas fa-arrow-right" aria-hidden="true"></i>
                                </a>
                            </div>
                        </div>
                    </article>
                <?php endforeach; ?>
                </div>
            </div>
        <?php endif; ?>
        <?php endif; ?>
        </div>
    </section>

    <!-- Modal nouveau devis -->
    <div id="modal-devis" class="modal-commande-manuelle <?php echo $show_modal_devis ? 'modal-open' : ''; ?>" role="dialog" aria-modal="true" aria-labelledby="modal-devis-title">
        <div class="modal-commande-manuelle-backdrop"></div>
        <div class="modal-commande-manuelle-content">
            <div class="modal-commande-manuelle-header">
                <h2 id="modal-devis-title"><i class="fas fa-file-invoice"></i> Nouveau devis</h2>
                <button type="button" class="modal-commande-manuelle-close" id="modal-devis-close" aria-label="Fermer">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="modal-commande-manuelle-body">
                <?php if ($devis_erreur): ?>
                    <div class="message error modal-commande-erreur">
                        <i class="fas fa-exclamation-circle"></i>
                        <span><?php echo htmlspecialchars($devis_erreur); ?></span>
                    </div>
                <?php endif; ?>

                <form method="POST" action="create.php" id="form-devis">
                    <input type="hidden" name="user_id" id="user_id" value="<?php echo htmlspecialchars($devis_post['user_id'] ?? ''); ?>">
                    <div class="form-commande-manuelle-grid">
                        <div class="form-commande-manuelle-col form-col-articles">
                            <div class="form-section-card">
                                <div class="form-section-header">
                                    <i class="fas fa-search"></i>
                                    <h3>Rechercher un produit</h3>
                                </div>
                                <div class="form-group search-group">
                                    <div class="search-input-wrapper">
                                        <input type="text" id="search-produit" placeholder="Tapez le nom du produit..." autocomplete="off">
                                        <i class="fas fa-search search-icon"></i>
                                        <span class="search-loading" id="search-loading" aria-hidden="true"><i class="fas fa-spinner fa-spin"></i></span>
                                    </div>
                                    <div id="search-produit-results" class="search-produit-results" role="listbox" aria-hidden="true"></div>
                                </div>
                                <p class="form-hint"><i class="fas fa-info-circle"></i> Tapez au moins 1 caractère ou laissez vide pour afficher tous les articles.</p>
                            </div>

                            <div class="form-section-card">
                                <div class="form-section-header">
                                    <i class="fas fa-shopping-cart"></i>
                                    <h3>Produits du devis</h3>
                                    <span class="lignes-count" id="lignes-count">0 article(s)</span>
                                </div>
                                <div id="lignes-commande" class="lignes-commande">
                                    <div class="lignes-empty" id="lignes-empty">
                                        <i class="fas fa-inbox"></i>
                                        <p>Aucun produit ajouté. Utilisez la recherche ci-dessus.</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="form-commande-manuelle-col form-col-client">
                            <div class="form-section-card">
                                <div class="form-section-header">
                                    <i class="fas fa-user"></i>
                                    <h3>Informations client</h3>
                                </div>
                                <div class="form-group search-group" style="position:relative;">
                                    <label for="search-client">Rechercher un client</label>
                                    <div class="search-input-wrapper">
                                        <input type="text" id="search-client" placeholder="Nom, téléphone ou email..." autocomplete="off">
                                        <i class="fas fa-search search-icon"></i>
                                        <span class="search-loading" id="search-client-loading" style="visibility:hidden;"><i class="fas fa-spinner fa-spin"></i></span>
                                    </div>
                                    <div id="search-client-results" class="search-produit-results" role="listbox" aria-hidden="true" style="position:absolute; left:0; right:0; top:100%; z-index:100;"></div>
                                    <p class="form-hint"><i class="fas fa-info-circle"></i> Recherchez un client ou saisissez manuellement ci-dessous.</p>
                                </div>
                                <div class="form-row-2">
                                    <div class="form-group">
                                        <label for="client_nom">Nom <span class="required">*</span></label>
                                        <input type="text" id="client_nom" name="client_nom" required
                                            value="<?php echo htmlspecialchars($devis_post['client_nom'] ?? ''); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="client_prenom">Prénom <span class="required">*</span></label>
                                        <input type="text" id="client_prenom" name="client_prenom" required
                                            value="<?php echo htmlspecialchars($devis_post['client_prenom'] ?? ''); ?>">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="client_telephone">Téléphone <span class="required">*</span></label>
                                    <input type="tel" id="client_telephone" name="client_telephone" required
                                        placeholder="Ex: 07 12 34 56 78"
                                        value="<?php echo htmlspecialchars($devis_post['client_telephone'] ?? ''); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="client_email">Email <span class="optional">(optionnel)</span></label>
                                    <input type="email" id="client_email" name="client_email"
                                        value="<?php echo htmlspecialchars($devis_post['client_email'] ?? ''); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="zone_livraison_id"><i class="fas fa-map-marker-alt"></i> Adresse de livraison <span class="required">*</span></label>
                                    <select id="zone_livraison_id" name="zone_livraison_id">
                                        <option value="">— Sélectionnez une adresse —</option>
                                        <?php foreach ($zones_livraison as $z): ?>
                                        <option value="<?php echo (int) $z['id']; ?>"
                                            data-adresse="<?php echo htmlspecialchars($z['ville'] . ' - ' . $z['quartier']); ?>"
                                            data-prix="<?php echo (float) $z['prix_livraison']; ?>"
                                            <?php echo (isset($devis_post['zone_livraison_id']) && (int)$devis_post['zone_livraison_id'] === (int)$z['id']) ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($z['ville'] . ' - ' . $z['quartier']); ?>
                                            (<?php echo number_format($z['prix_livraison'], 0, ',', ' '); ?> FCFA)
                                        </option>
                                        <?php endforeach; ?>
                                        <option value="custom" <?php echo (isset($devis_post['zone_livraison_id']) && $devis_post['zone_livraison_id'] === 'custom') ? 'selected' : ''; ?>>— Adresse personnalisée —</option>
                                    </select>
                                    <div id="adresse-custom-wrap" class="adresse-custom-wrap" style="display:none; margin-top:10px;">
                                        <textarea id="adresse_livraison_ta" rows="3" placeholder="Saisissez l'adresse complète"><?php echo htmlspecialchars($devis_post['adresse_livraison'] ?? ''); ?></textarea>
                                    </div>
                                    <div id="adresse-zone-display" class="adresse-zone-display" style="display:none; margin-top:8px; padding:10px; background:#f5f5f4; border-radius:8px;"></div>
                                    <input type="hidden" name="adresse_livraison" id="adresse_livraison" value="">
                                    <input type="hidden" name="frais_livraison" id="frais_livraison" value="0">
                                </div>
                                <div class="form-group">
                                    <label for="notes">Notes</label>
                                    <textarea id="notes" name="notes" rows="2" placeholder="Instructions supplémentaires..."><?php echo htmlspecialchars($devis_post['notes'] ?? ''); ?></textarea>
                                </div>
                                <div class="commande-manuelle-recap">
                                    <div class="recap-line">
                                        <span>Sous-total produits</span>
                                        <span id="recap-sous-total">0 FCFA</span>
                                    </div>
                                    <div class="recap-line">
                                        <span>Frais de livraison</span>
                                        <span id="recap-frais">0 FCFA</span>
                                    </div>
                                    <div class="recap-line recap-total">
                                        <span>Total</span>
                                        <span id="recap-total">0 FCFA</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="form-commande-manuelle-actions">
                        <button type="button" class="btn-secondary" id="modal-devis-cancel">Annuler</button>
                        <button type="submit" class="btn-primary btn-submit-commande" name="submit_devis">
                            <i class="fas fa-check"></i> Créer le devis
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php if ($bl_tables_ok): ?>
    <!-- Modal BL : mêmes champs et même structure que le modal devis (+ date BL + statut) -->
    <div id="modal-bl" class="modal-commande-manuelle <?php echo $show_modal_bl ? 'modal-open' : ''; ?>" role="dialog" aria-modal="true" aria-labelledby="modal-bl-title">
        <div class="modal-commande-manuelle-backdrop" id="modal-bl-backdrop"></div>
        <div class="modal-commande-manuelle-content">
            <div class="modal-commande-manuelle-header">
                <h2 id="modal-bl-title"><i class="fas fa-truck-loading"></i> Nouveau bon de livraison</h2>
                <button type="button" class="modal-commande-manuelle-close" id="modal-bl-close" aria-label="Fermer">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="modal-commande-manuelle-body">
                <?php if ($bl_modal_err): ?>
                    <div class="message error modal-commande-erreur">
                        <i class="fas fa-exclamation-circle"></i>
                        <span><?php echo htmlspecialchars($bl_modal_err); ?></span>
                    </div>
                <?php endif; ?>

                <form method="POST" action="bl_enregistrer.php" id="form-bl">
                    <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['admin_csrf']); ?>">
                    <input type="hidden" name="user_id" id="user_id_bl" value="<?php echo htmlspecialchars($bp['user_id'] ?? ''); ?>">
                    <div class="form-commande-manuelle-grid">
                        <div class="form-commande-manuelle-col form-col-articles">
                            <div class="form-section-card">
                                <div class="form-section-header">
                                    <i class="fas fa-search"></i>
                                    <h3>Rechercher un produit</h3>
                                </div>
                                <div class="form-group search-group">
                                    <div class="search-input-wrapper">
                                        <input type="text" id="search-produit-bl" placeholder="Tapez le nom du produit..." autocomplete="off">
                                        <i class="fas fa-search search-icon"></i>
                                        <span class="search-loading" id="search-loading-bl" aria-hidden="true"><i class="fas fa-spinner fa-spin"></i></span>
                                    </div>
                                    <div id="search-produit-results-bl" class="search-produit-results" role="listbox" aria-hidden="true"></div>
                                </div>
                                <p class="form-hint"><i class="fas fa-info-circle"></i> Tapez au moins 1 caractère ou laissez vide pour afficher tous les articles.</p>
                            </div>

                            <div class="form-section-card">
                                <div class="form-section-header">
                                    <i class="fas fa-shopping-cart"></i>
                                    <h3>Produits du devis</h3>
                                    <span class="lignes-count" id="lignes-count-bl">0 article(s)</span>
                                </div>
                                <div id="lignes-commande-bl" class="lignes-commande lignes-commande-bl-wrap">
                                    <div class="ligne-commande-head ligne-commande-head-bl" id="lignes-head-bl" hidden>
                                        <span class="lch-head-cell">Désignation du produit</span>
                                        <span class="lch-head-cell">Quantité</span>
                                        <span class="lch-head-cell">Prix unitaire <span class="lch-fcfa">FCFA</span></span>
                                        <span class="lch-head-cell">Prix promo <span class="lch-fcfa">FCFA</span></span>
                                        <span class="lch-head-cell lch-head-actions" aria-hidden="true"></span>
                                    </div>
                                    <div class="lignes-empty" id="lignes-empty-bl">
                                        <i class="fas fa-inbox"></i>
                                        <p>Aucun produit ajouté. Utilisez la recherche ci-dessus.</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="form-commande-manuelle-col form-col-client">
                            <div class="form-section-card">
                                <div class="form-section-header">
                                    <i class="fas fa-user"></i>
                                    <h3>Informations client</h3>
                                </div>
                                <div class="form-group search-group" style="position:relative;">
                                    <label for="search-client-bl">Rechercher un client</label>
                                    <div class="search-input-wrapper">
                                        <input type="text" id="search-client-bl" placeholder="Nom, téléphone ou email..." autocomplete="off">
                                        <i class="fas fa-search search-icon"></i>
                                        <span class="search-loading" id="search-client-loading-bl" style="visibility:hidden;"><i class="fas fa-spinner fa-spin"></i></span>
                                    </div>
                                    <div id="search-client-results-bl" class="search-produit-results" role="listbox" aria-hidden="true" style="position:absolute; left:0; right:0; top:100%; z-index:100;"></div>
                                    <p class="form-hint"><i class="fas fa-info-circle"></i> Recherchez un client ou saisissez manuellement ci-dessous.</p>
                                </div>
                                <div class="form-row-2">
                                    <div class="form-group">
                                        <label for="client_nom_bl">Nom <span class="required">*</span></label>
                                        <input type="text" id="client_nom_bl" name="client_nom" required
                                            value="<?php echo htmlspecialchars($bp['client_nom'] ?? ''); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="client_prenom_bl">Prénom <span class="required">*</span></label>
                                        <input type="text" id="client_prenom_bl" name="client_prenom" required
                                            value="<?php echo htmlspecialchars($bp['client_prenom'] ?? ''); ?>">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="client_telephone_bl">Téléphone <span class="required">*</span></label>
                                    <input type="tel" id="client_telephone_bl" name="client_telephone" required
                                        placeholder="Ex: 07 12 34 56 78"
                                        value="<?php echo htmlspecialchars($bp['client_telephone'] ?? ''); ?>">
                                    <p class="form-hint" style="margin-top:8px;"><i class="fas fa-address-book"></i> Le carnet <strong>Contacts</strong> est mis à jour automatiquement : si ce numéro n’y figure pas encore, le contact (nom, prénom, téléphone, email) est enregistré.</p>
                                </div>
                                <div class="form-group">
                                    <label for="client_email_bl">Email <span class="optional">(optionnel)</span></label>
                                    <input type="email" id="client_email_bl" name="client_email"
                                        value="<?php echo htmlspecialchars($bp['client_email'] ?? ''); ?>">
                                </div>
                                <div class="form-group">
                                    <label for="zone_livraison_id_bl"><i class="fas fa-map-marker-alt"></i> Adresse de livraison <span class="required">*</span></label>
                                    <select id="zone_livraison_id_bl" name="zone_livraison_id">
                                        <option value="">— Sélectionnez une adresse —</option>
                                        <?php foreach ($zones_livraison as $z): ?>
                                        <option value="<?php echo (int) $z['id']; ?>"
                                            data-adresse="<?php echo htmlspecialchars($z['ville'] . ' - ' . $z['quartier']); ?>"
                                            data-prix="<?php echo (float) $z['prix_livraison']; ?>"
                                            <?php echo (isset($bp['zone_livraison_id']) && (string) $bp['zone_livraison_id'] === (string) $z['id']) ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($z['ville'] . ' - ' . $z['quartier']); ?>
                                            (<?php echo number_format($z['prix_livraison'], 0, ',', ' '); ?> FCFA)
                                        </option>
                                        <?php endforeach; ?>
                                        <option value="custom" <?php echo (isset($bp['zone_livraison_id']) && $bp['zone_livraison_id'] === 'custom') ? 'selected' : ''; ?>>— Adresse personnalisée —</option>
                                    </select>
                                    <div id="adresse-custom-wrap-bl" class="adresse-custom-wrap" style="display:none; margin-top:10px;">
                                        <textarea id="adresse_livraison_ta_bl" rows="3" placeholder="Saisissez l'adresse complète"><?php echo htmlspecialchars($bp['adresse_livraison'] ?? ''); ?></textarea>
                                    </div>
                                    <div id="adresse-zone-display-bl" class="adresse-zone-display" style="display:none; margin-top:8px; padding:10px; background:#f5f5f4; border-radius:8px;"></div>
                                    <input type="hidden" name="adresse_livraison" id="adresse_livraison_bl" value="">
                                    <input type="hidden" name="frais_livraison" id="frais_livraison_bl" value="0">
                                </div>
                                <div class="form-group">
                                    <label for="notes_bl">Notes</label>
                                    <textarea id="notes_bl" name="notes" rows="2" placeholder="Instructions supplémentaires..."><?php echo htmlspecialchars($bp['notes'] ?? ''); ?></textarea>
                                </div>
                                <div class="form-row-2">
                                    <div class="form-group">
                                        <label for="date_bl">Date du BL</label>
                                        <input type="date" name="date_bl" id="date_bl" value="<?php echo htmlspecialchars($bp['date_bl'] ?? date('Y-m-d')); ?>">
                                    </div>
                                    <div class="form-group">
                                        <label for="statut_bl_sel">Statut du BL</label>
                                        <select name="statut" id="statut_bl_sel">
                                            <?php
                                            $sb = $bp['statut'] ?? 'brouillon';
                                            if (!in_array($sb, ['brouillon', 'valide'], true)) {
                                                $sb = 'brouillon';
                                            }
                                            ?>
                                            <option value="brouillon" <?php echo $sb === 'brouillon' ? 'selected' : ''; ?>>Brouillon</option>
                                            <option value="valide" <?php echo $sb === 'valide' ? 'selected' : ''; ?>>Validé (comptabilité)</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="commande-manuelle-recap">
                                    <div class="recap-line">
                                        <span>Sous-total produits</span>
                                        <span id="recap-sous-total-bl">0 FCFA</span>
                                    </div>
                                    <div class="recap-line">
                                        <span>Frais de livraison</span>
                                        <span id="recap-frais-bl">0 FCFA</span>
                                    </div>
                                    <div class="recap-line recap-total">
                                        <span>Total</span>
                                        <span id="recap-total-bl">0 FCFA</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="form-commande-manuelle-actions">
                        <button type="button" class="btn-secondary" id="modal-bl-cancel">Annuler</button>
                        <button type="submit" class="btn-primary btn-submit-commande" name="submit_bl">
                            <i class="fas fa-check"></i> Enregistrer le BL
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <?php include '../includes/footer.php'; ?>

    <script>
    (function() {
        /* Échappe les valeurs JSON (noms, emails…) avant insertion via innerHTML */
        function escapeHtml(v) {
            return String(v == null ? '' : v).replace(/&/g, '&amp;').replace(/</g, '&lt;')
                .replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
        }
        var modal = document.getElementById('modal-devis');
        var btnOpen = document.getElementById('btn-nouveau-devis');
        var btnClose = document.getElementById('modal-devis-close');
        var btnCancel = document.getElementById('modal-devis-cancel');
        var backdrop = modal ? modal.querySelector('.modal-commande-manuelle-backdrop') : null;
        var searchInput = document.getElementById('search-produit');
        var searchResults = document.getElementById('search-produit-results');
        var searchLoading = document.getElementById('search-loading');
        var lignesContainer = document.getElementById('lignes-commande');
        var lignesEmpty = document.getElementById('lignes-empty');
        var lignesCount = document.getElementById('lignes-count');
        var ligneIndex = 0;
        var ajaxUrl = 'ajax_search_produits.php';

        function openModal() {
            var tabDevisBtn = document.getElementById('tab-btn-devis');
            if (tabDevisBtn) {
                tabDevisBtn.click();
            }
            if (modal) modal.classList.add('modal-open');
            document.body.style.overflow = 'hidden';
        }
        function closeModal() {
            if (modal) modal.classList.remove('modal-open');
            document.body.style.overflow = '';
        }

        if (btnOpen) btnOpen.addEventListener('click', openModal);
        if (btnClose) btnClose.addEventListener('click', closeModal);
        if (btnCancel) btnCancel.addEventListener('click', closeModal);
        if (backdrop) backdrop.addEventListener('click', closeModal);

        if (modal && modal.classList.contains('modal-open')) document.body.style.overflow = 'hidden';

        function updateLignesUI() {
            var items = lignesContainer ? lignesContainer.querySelectorAll('.ligne-commande-item') : [];
            var n = items.length;
            if (lignesEmpty) lignesEmpty.style.display = n === 0 ? 'flex' : 'none';
            if (lignesCount) lignesCount.textContent = n + ' article(s)';
        }

        function addLigne(produit) {
            var prix = parseFloat(produit.prix) || 0;
            var prixPromo = produit.prix_promotion && parseFloat(produit.prix_promotion) > 0 ? parseFloat(produit.prix_promotion) : '';
            var nom = (produit.nom || '');
            var idx = ligneIndex++;
            var div = document.createElement('div');
            div.className = 'ligne-commande-item';
            div.dataset.produitId = produit.id;
            div.innerHTML =
                '<input type="hidden" name="lignes[' + idx + '][produit_id]" value="' + escapeHtml(produit.id) + '">' +
                '<input type="text" name="lignes[' + idx + '][nom_produit]" value="' + escapeHtml(nom) + '" placeholder="Nom du produit (modifiable)" class="ligne-nom-input" title="Modifier le nom affiché">' +
                '<input type="number" name="lignes[' + idx + '][quantite]" value="1" min="1" max="' + escapeHtml(produit.stock_dispo || produit.stock || 999) + '" class="ligne-qte" title="Quantité">' +
                '<input type="number" name="lignes[' + idx + '][prix_unitaire]" value="' + (prixPromo || prix) + '" min="0" step="0.01" class="ligne-prix" title="Prix unitaire (FCFA)">' +
                '<input type="number" name="lignes[' + idx + '][prix_promotion]" value="' + (prixPromo || '') + '" min="0" step="0.01" placeholder="Optionnel" class="ligne-prix-promo" title="Prix promo (optionnel)">' +
                '<button type="button" class="ligne-remove" aria-label="Retirer"><i class="fas fa-trash"></i></button>';
            if (lignesEmpty) lignesEmpty.style.display = 'none';
            div.querySelector('.ligne-remove').addEventListener('click', function() {
                div.remove();
                updateLignesUI();
                updateRecap();
            });
            lignesContainer.appendChild(div);
            updateLignesUI();
            updateRecap();
        }

        function doSearch(q) {
            if (searchLoading) searchLoading.style.visibility = 'visible';
            fetch(ajaxUrl + '?q=' + encodeURIComponent(q) + '&limit=25')
                .then(function(r) { return r.json(); })
                .then(function(data) {
                    var items = data.items || [];
                    searchResults.innerHTML = '';
                    if (items.length === 0) {
                        searchResults.innerHTML = '<div class="search-no-results"><i class="fas fa-box-open"></i> Aucun produit trouvé.</div>';
                    } else {
                        items.forEach(function(p) {
                            var el = document.createElement('div');
                            el.className = 'search-result-item';
                            el.setAttribute('role', 'option');
                            el.setAttribute('tabindex', '0');
                            var stock = p.stock_dispo || p.stock || 0;
                            var prix = parseFloat(p.prix) || 0;
                            el.innerHTML = '<span class="sr-nom">' + escapeHtml(p.nom) + '</span>' +
                                '<span class="sr-meta">' + escapeHtml(p.categorie_nom) + ' &bull; Stock: ' + escapeHtml(stock) + ' &bull; ' + prix + ' FCFA</span>';
                            el.addEventListener('mousedown', function(ev) {
                                ev.preventDefault();
                                addLigne(p);
                                searchInput.value = '';
                                searchResults.innerHTML = '';
                                searchResults.setAttribute('aria-hidden', 'true');
                            });
                            el.addEventListener('keydown', function(ev) {
                                if (ev.key === 'Enter' || ev.key === ' ') {
                                    ev.preventDefault();
                                    addLigne(p);
                                    searchInput.value = '';
                                    searchResults.innerHTML = '';
                                    searchResults.setAttribute('aria-hidden', 'true');
                                }
                            });
                            searchResults.appendChild(el);
                        });
                    }
                    searchResults.setAttribute('aria-hidden', 'false');
                })
                .catch(function() {
                    searchResults.innerHTML = '<div class="search-no-results"><i class="fas fa-exclamation-triangle"></i> Erreur de recherche.</div>';
                })
                .finally(function() {
                    if (searchLoading) searchLoading.style.visibility = 'hidden';
                });
        }

        var zoneSelect = document.getElementById('zone_livraison_id');
        var adresseCustomWrap = document.getElementById('adresse-custom-wrap');
        var adresseZoneDisplay = document.getElementById('adresse-zone-display');
        var adresseLivraison = document.getElementById('adresse_livraison');
        var adresseTa = document.getElementById('adresse_livraison_ta');
        var fraisInput = document.getElementById('frais_livraison');
        var recapSousTotal = document.getElementById('recap-sous-total');
        var recapFrais = document.getElementById('recap-frais');
        var recapTotal = document.getElementById('recap-total');
        var formDevis = document.getElementById('form-devis');

        function formatNumber(n) {
            return Math.round(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
        }

        function getSousTotal() {
            var total = 0;
            var items = lignesContainer ? lignesContainer.querySelectorAll('.ligne-commande-item') : [];
            items.forEach(function(row) {
                var qte = parseFloat(row.querySelector('.ligne-qte').value) || 0;
                var prix = parseFloat(row.querySelector('.ligne-prix').value) || 0;
                var promo = row.querySelector('.ligne-prix-promo');
                var p = promo && promo.value && parseFloat(promo.value) > 0 ? parseFloat(promo.value) : prix;
                total += p * qte;
            });
            return total;
        }

        function getFraisLivraison() {
            if (!zoneSelect || zoneSelect.value === '' || zoneSelect.value === 'custom') return 0;
            var opt = zoneSelect.options[zoneSelect.selectedIndex];
            return opt && opt.dataset.prix ? parseFloat(opt.dataset.prix) : 0;
        }

        function updateRecap() {
            var sousTotal = getSousTotal();
            var frais = getFraisLivraison();
            var total = sousTotal + frais;
            if (recapSousTotal) recapSousTotal.textContent = formatNumber(sousTotal) + ' FCFA';
            if (recapFrais) recapFrais.textContent = formatNumber(frais) + ' FCFA';
            if (recapTotal) recapTotal.textContent = formatNumber(total) + ' FCFA';
            if (fraisInput) fraisInput.value = frais;
        }

        function onZoneChange() {
            var val = zoneSelect ? zoneSelect.value : '';
            if (val === 'custom') {
                if (adresseCustomWrap) adresseCustomWrap.style.display = 'block';
                if (adresseZoneDisplay) adresseZoneDisplay.style.display = 'none';
                if (adresseLivraison) adresseLivraison.value = '';
            } else if (val !== '') {
                var opt = zoneSelect.options[zoneSelect.selectedIndex];
                var adr = opt && opt.dataset.adresse ? opt.dataset.adresse : '';
                if (adresseLivraison) adresseLivraison.value = adr;
                if (adresseCustomWrap) adresseCustomWrap.style.display = 'none';
                if (adresseZoneDisplay) {
                    adresseZoneDisplay.textContent = adr;
                    adresseZoneDisplay.style.display = 'block';
                }
            } else {
                if (adresseCustomWrap) adresseCustomWrap.style.display = 'none';
                if (adresseZoneDisplay) adresseZoneDisplay.style.display = 'none';
                if (adresseLivraison) adresseLivraison.value = '';
            }
            updateRecap();
        }

        if (zoneSelect) zoneSelect.addEventListener('change', onZoneChange);

        if (lignesContainer) {
            lignesContainer.addEventListener('input', function(ev) {
                if (ev.target.classList.contains('ligne-qte') || ev.target.classList.contains('ligne-prix') || ev.target.classList.contains('ligne-prix-promo')) {
                    updateRecap();
                }
            });
        }

        if (formDevis) {
            formDevis.addEventListener('submit', function(ev) {
                if (zoneSelect && zoneSelect.value === 'custom' && adresseTa) {
                    if (adresseLivraison) adresseLivraison.value = adresseTa.value.trim();
                } else if (zoneSelect && zoneSelect.value && zoneSelect.value !== 'custom') {
                    onZoneChange();
                }
                if (adresseLivraison && !adresseLivraison.value.trim()) {
                    ev.preventDefault();
                    alert('Veuillez sélectionner une adresse de livraison ou saisir une adresse personnalisée.');
                    return false;
                }
            });
        }

        var searchTimeout;
        if (searchInput && searchResults) {
            searchInput.addEventListener('input', function() {
                clearTimeout(searchTimeout);
                var q = searchInput.value.trim();
                searchTimeout = setTimeout(function() { doSearch(q); }, 250);
            });
            searchInput.addEventListener('focus', function() {
                var q = searchInput.value.trim();
                if (searchResults.getAttribute('aria-hidden') === 'true' || searchResults.innerHTML === '') {
                    doSearch(q);
                }
            });
            searchInput.addEventListener('blur', function() {
                setTimeout(function() {
                    if (!searchResults.contains(document.activeElement)) {
                        searchResults.innerHTML = '';
                        searchResults.setAttribute('aria-hidden', 'true');
                    }
                }, 150);
            });
            searchResults.addEventListener('mousedown', function(ev) { ev.preventDefault(); });
        }

        var searchClientInput = document.getElementById('search-client');
        var searchClientResults = document.getElementById('search-client-results');
        var searchClientLoading = document.getElementById('search-client-loading');
        var clientNomInput = document.getElementById('client_nom');
        var clientPrenomInput = document.getElementById('client_prenom');
        var clientTelInput = document.getElementById('client_telephone');
        var clientEmailInput = document.getElementById('client_email');
        var userIdInput = document.getElementById('user_id');
        var clientSearchTimeout;
        if (searchClientInput && searchClientResults && clientNomInput && clientPrenomInput && clientTelInput) {
            function doClientSearch(q) {
                if (q.length < 1) {
                    searchClientResults.innerHTML = '';
                    searchClientResults.setAttribute('aria-hidden', 'true');
                    return;
                }
                if (searchClientLoading) searchClientLoading.style.visibility = 'visible';
                fetch('ajax_search_clients.php?q=' + encodeURIComponent(q) + '&limit=15')
                    .then(function(r) { return r.json(); })
                    .then(function(data) {
                        searchClientResults.innerHTML = '';
                        if (data.length === 0) {
                            searchClientResults.innerHTML = '<div class="search-no-results">Aucun client trouvé.</div>';
                        } else {
                            data.forEach(function(c) {
                                var el = document.createElement('div');
                                el.className = 'search-result-item';
                                el.setAttribute('role', 'option');
                                el.innerHTML = '<span class="sr-nom">' + escapeHtml(c.nom_complet) + '</span>' +
                                    '<span class="sr-meta">' + escapeHtml(c.telephone) + (c.email ? ' &bull; ' + escapeHtml(c.email) : '') + '</span>';
                                el.addEventListener('mousedown', function(ev) {
                                    ev.preventDefault();
                                    clientNomInput.value = c.nom || '';
                                    clientPrenomInput.value = c.prenom || '';
                                    clientTelInput.value = c.telephone || '';
                                    if (clientEmailInput) clientEmailInput.value = c.email || '';
                                    if (userIdInput) userIdInput.value = (c.source === 'user') ? c.id : '';
                                    searchClientInput.value = '';
                                    searchClientResults.innerHTML = '';
                                    searchClientResults.setAttribute('aria-hidden', 'true');
                                });
                                searchClientResults.appendChild(el);
                            });
                        }
                        searchClientResults.setAttribute('aria-hidden', 'false');
                    })
                    .catch(function() {
                        searchClientResults.innerHTML = '<div class="search-no-results">Erreur de recherche.</div>';
                    })
                    .finally(function() {
                        if (searchClientLoading) searchClientLoading.style.visibility = 'hidden';
                    });
            }
            searchClientInput.addEventListener('input', function() {
                clearTimeout(clientSearchTimeout);
                var q = searchClientInput.value.trim();
                clientSearchTimeout = setTimeout(function() { doClientSearch(q); }, 300);
            });
            searchClientInput.addEventListener('focus', function() {
                var q = searchClientInput.value.trim();
                if (q.length >= 1) doClientSearch(q);
            });
            searchClientInput.addEventListener('blur', function() {
                setTimeout(function() {
                    if (!searchClientResults.contains(document.activeElement)) {
                        searchClientResults.innerHTML = '';
                        searchClientResults.setAttribute('aria-hidden', 'true');
                    }
                }, 150);
            });
            searchClientResults.addEventListener('mousedown', function(ev) { ev.preventDefault(); });
        }

        updateLignesUI();
        if (modal && modal.classList.contains('modal-open') && zoneSelect && zoneSelect.value) {
            onZoneChange();
        }
    })();

    (function() {
        /* Échappe les valeurs JSON (noms, emails…) avant insertion via innerHTML */
        function escapeHtml(v) {
            return String(v == null ? '' : v).replace(/&/g, '&amp;').replace(/</g, '&lt;')
                .replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
        }
        var tabDevis = document.getElementById('tab-btn-devis');
        var tabBl = document.getElementById('tab-btn-bl');
        var panelDevis = document.getElementById('panel-devis');
        var panelBl = document.getElementById('panel-bl');

        function showTab(which) {
            if (!panelDevis || !panelBl) return;
            if (which === 'bl') {
                panelDevis.setAttribute('hidden', 'hidden');
                panelDevis.classList.remove('is-active');
                panelBl.removeAttribute('hidden');
                panelBl.classList.add('is-active');
                if (tabDevis) {
                    tabDevis.classList.remove('is-active');
                    tabDevis.setAttribute('aria-selected', 'false');
                }
                if (tabBl) {
                    tabBl.classList.add('is-active');
                    tabBl.setAttribute('aria-selected', 'true');
                }
            } else {
                panelBl.setAttribute('hidden', 'hidden');
                panelBl.classList.remove('is-active');
                panelDevis.removeAttribute('hidden');
                panelDevis.classList.add('is-active');
                if (tabBl) {
                    tabBl.classList.remove('is-active');
                    tabBl.setAttribute('aria-selected', 'false');
                }
                if (tabDevis) {
                    tabDevis.classList.add('is-active');
                    tabDevis.setAttribute('aria-selected', 'true');
                }
            }
        }

        if (tabDevis) tabDevis.addEventListener('click', function() { showTab('devis'); });
        if (tabBl) tabBl.addEventListener('click', function() { if (!tabBl.disabled) showTab('bl'); });

        var modalBl = document.getElementById('modal-bl');
        var btnOpenBl = document.getElementById('btn-nouveau-bl');
        var btnCloseBl = document.getElementById('modal-bl-close');
        var btnCancelBl = document.getElementById('modal-bl-cancel');
        var backdropBl = document.getElementById('modal-bl-backdrop');

        function openModalBl() {
            showTab('bl');
            if (modalBl) {
                modalBl.classList.add('modal-open');
                document.body.style.overflow = 'hidden';
            }
        }
        function closeModalBl() {
            if (modalBl) {
                modalBl.classList.remove('modal-open');
                document.body.style.overflow = '';
            }
        }

        if (btnOpenBl) btnOpenBl.addEventListener('click', openModalBl);
        if (btnCloseBl) btnCloseBl.addEventListener('click', closeModalBl);
        if (btnCancelBl) btnCancelBl.addEventListener('click', closeModalBl);
        if (backdropBl) backdropBl.addEventListener('click', closeModalBl);

        if (modalBl && modalBl.classList.contains('modal-open')) {
            document.body.style.overflow = 'hidden';
            showTab('bl');
        }

        /* ——— Même logique que le modal devis (recherche produits, lignes, zone, client, recap) ——— */
        var searchInputBl = document.getElementById('search-produit-bl');
        var searchResultsBl = document.getElementById('search-produit-results-bl');
        var searchLoadingBl = document.getElementById('search-loading-bl');
        var lignesContainerBl = document.getElementById('lignes-commande-bl');
        var lignesEmptyBl = document.getElementById('lignes-empty-bl');
        var lignesCountBl = document.getElementById('lignes-count-bl');
        var ligneIndexBl = 0;
        var ajaxUrlBl = 'ajax_search_produits.php';

        function updateLignesUIBl() {
            var items = lignesContainerBl ? lignesContainerBl.querySelectorAll('.ligne-commande-item') : [];
            var n = items.length;
            if (lignesEmptyBl) lignesEmptyBl.style.display = n === 0 ? 'flex' : 'none';
            if (lignesCountBl) lignesCountBl.textContent = n + ' article(s)';
            var headBl = document.getElementById('lignes-head-bl');
            if (headBl) {
                if (n > 0) {
                    headBl.removeAttribute('hidden');
                } else {
                    headBl.setAttribute('hidden', 'hidden');
                }
            }
        }

        function addLigneBl(produit) {
            var prix = parseFloat(produit.prix) || 0;
            var prixPromo = produit.prix_promotion && parseFloat(produit.prix_promotion) > 0 ? parseFloat(produit.prix_promotion) : '';
            var nom = (produit.nom || '');
            var idx = ligneIndexBl++;
            var div = document.createElement('div');
            div.className = 'ligne-commande-item ligne-commande-item-bl';
            div.dataset.produitId = produit.id;
            div.innerHTML =
                '<div class="ligne-bl-cell">' +
                    '<input type="hidden" name="lignes[' + idx + '][produit_id]" value="' + escapeHtml(produit.id) + '">' +
                    '<span class="ligne-bl-label">Désignation</span>' +
                    '<input type="text" name="lignes[' + idx + '][nom_produit]" value="' + escapeHtml(nom) + '" placeholder="Nom du produit" class="ligne-nom-input" aria-label="Désignation du produit">' +
                '</div>' +
                '<div class="ligne-bl-cell">' +
                    '<span class="ligne-bl-label">Quantité</span>' +
                    '<input type="number" name="lignes[' + idx + '][quantite]" value="1" min="1" max="' + escapeHtml(produit.stock_dispo || produit.stock || 999) + '" class="ligne-qte" aria-label="Quantité">' +
                '</div>' +
                '<div class="ligne-bl-cell ligne-bl-cell-prix">' +
                    '<span class="ligne-bl-label">Prix unitaire</span>' +
                    '<div class="ligne-bl-prix-row">' +
                        '<input type="number" name="lignes[' + idx + '][prix_unitaire]" value="' + (prixPromo || prix) + '" min="0" step="0.01" class="ligne-prix" aria-label="Prix unitaire en FCFA">' +
                        '<span class="ligne-unit-fcfa">FCFA</span>' +
                    '</div>' +
                '</div>' +
                '<div class="ligne-bl-cell ligne-bl-cell-prix">' +
                    '<span class="ligne-bl-label">Prix promo</span>' +
                    '<div class="ligne-bl-prix-row">' +
                        '<input type="number" name="lignes[' + idx + '][prix_promotion]" value="' + (prixPromo || '') + '" min="0" step="0.01" placeholder="Optionnel" class="ligne-prix-promo" aria-label="Prix promotionnel en FCFA">' +
                        '<span class="ligne-unit-fcfa">FCFA</span>' +
                    '</div>' +
                '</div>' +
                '<button type="button" class="ligne-remove" aria-label="Retirer la ligne"><i class="fas fa-trash"></i></button>';
            if (lignesEmptyBl) lignesEmptyBl.style.display = 'none';
            div.querySelector('.ligne-remove').addEventListener('click', function() {
                div.remove();
                updateLignesUIBl();
                updateRecapBl();
            });
            lignesContainerBl.appendChild(div);
            updateLignesUIBl();
            updateRecapBl();
        }

        function doSearchBl(q) {
            if (searchLoadingBl) searchLoadingBl.style.visibility = 'visible';
            fetch(ajaxUrlBl + '?q=' + encodeURIComponent(q) + '&limit=25')
                .then(function(r) { return r.json(); })
                .then(function(data) {
                    var items = data.items || [];
                    searchResultsBl.innerHTML = '';
                    if (items.length === 0) {
                        searchResultsBl.innerHTML = '<div class="search-no-results"><i class="fas fa-box-open"></i> Aucun produit trouvé.</div>';
                    } else {
                        items.forEach(function(p) {
                            var el = document.createElement('div');
                            el.className = 'search-result-item';
                            el.setAttribute('role', 'option');
                            el.setAttribute('tabindex', '0');
                            var stock = p.stock_dispo || p.stock || 0;
                            var prix = parseFloat(p.prix) || 0;
                            el.innerHTML = '<span class="sr-nom">' + escapeHtml(p.nom) + '</span>' +
                                '<span class="sr-meta">' + escapeHtml(p.categorie_nom) + ' &bull; Stock: ' + escapeHtml(stock) + ' &bull; ' + prix + ' FCFA</span>';
                            el.addEventListener('mousedown', function(ev) {
                                ev.preventDefault();
                                addLigneBl(p);
                                searchInputBl.value = '';
                                searchResultsBl.innerHTML = '';
                                searchResultsBl.setAttribute('aria-hidden', 'true');
                            });
                            el.addEventListener('keydown', function(ev) {
                                if (ev.key === 'Enter' || ev.key === ' ') {
                                    ev.preventDefault();
                                    addLigneBl(p);
                                    searchInputBl.value = '';
                                    searchResultsBl.innerHTML = '';
                                    searchResultsBl.setAttribute('aria-hidden', 'true');
                                }
                            });
                            searchResultsBl.appendChild(el);
                        });
                    }
                    searchResultsBl.setAttribute('aria-hidden', 'false');
                })
                .catch(function() {
                    searchResultsBl.innerHTML = '<div class="search-no-results"><i class="fas fa-exclamation-triangle"></i> Erreur de recherche.</div>';
                })
                .finally(function() {
                    if (searchLoadingBl) searchLoadingBl.style.visibility = 'hidden';
                });
        }

        var zoneSelectBl = document.getElementById('zone_livraison_id_bl');
        var adresseCustomWrapBl = document.getElementById('adresse-custom-wrap-bl');
        var adresseZoneDisplayBl = document.getElementById('adresse-zone-display-bl');
        var adresseLivraisonBl = document.getElementById('adresse_livraison_bl');
        var adresseTaBl = document.getElementById('adresse_livraison_ta_bl');
        var fraisInputBl = document.getElementById('frais_livraison_bl');
        var recapSousTotalBl = document.getElementById('recap-sous-total-bl');
        var recapFraisBl = document.getElementById('recap-frais-bl');
        var recapTotalBl = document.getElementById('recap-total-bl');
        var formBl = document.getElementById('form-bl');

        function formatNumberBl(n) {
            return Math.round(n).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
        }

        function getSousTotalBl() {
            var total = 0;
            var items = lignesContainerBl ? lignesContainerBl.querySelectorAll('.ligne-commande-item') : [];
            items.forEach(function(row) {
                var qte = parseFloat(row.querySelector('.ligne-qte').value) || 0;
                var prix = parseFloat(row.querySelector('.ligne-prix').value) || 0;
                var promo = row.querySelector('.ligne-prix-promo');
                var p = promo && promo.value && parseFloat(promo.value) > 0 ? parseFloat(promo.value) : prix;
                total += p * qte;
            });
            return total;
        }

        function getFraisLivraisonBl() {
            if (!zoneSelectBl || zoneSelectBl.value === '' || zoneSelectBl.value === 'custom') return 0;
            var opt = zoneSelectBl.options[zoneSelectBl.selectedIndex];
            return opt && opt.dataset.prix ? parseFloat(opt.dataset.prix) : 0;
        }

        function updateRecapBl() {
            var sousTotal = getSousTotalBl();
            var frais = getFraisLivraisonBl();
            var total = sousTotal + frais;
            if (recapSousTotalBl) recapSousTotalBl.textContent = formatNumberBl(sousTotal) + ' FCFA';
            if (recapFraisBl) recapFraisBl.textContent = formatNumberBl(frais) + ' FCFA';
            if (recapTotalBl) recapTotalBl.textContent = formatNumberBl(total) + ' FCFA';
            if (fraisInputBl) fraisInputBl.value = frais;
        }

        function onZoneChangeBl() {
            var val = zoneSelectBl ? zoneSelectBl.value : '';
            if (val === 'custom') {
                if (adresseCustomWrapBl) adresseCustomWrapBl.style.display = 'block';
                if (adresseZoneDisplayBl) adresseZoneDisplayBl.style.display = 'none';
                if (adresseLivraisonBl) adresseLivraisonBl.value = '';
            } else if (val !== '') {
                var opt = zoneSelectBl.options[zoneSelectBl.selectedIndex];
                var adr = opt && opt.dataset.adresse ? opt.dataset.adresse : '';
                if (adresseLivraisonBl) adresseLivraisonBl.value = adr;
                if (adresseCustomWrapBl) adresseCustomWrapBl.style.display = 'none';
                if (adresseZoneDisplayBl) {
                    adresseZoneDisplayBl.textContent = adr;
                    adresseZoneDisplayBl.style.display = 'block';
                }
            } else {
                if (adresseCustomWrapBl) adresseCustomWrapBl.style.display = 'none';
                if (adresseZoneDisplayBl) adresseZoneDisplayBl.style.display = 'none';
                if (adresseLivraisonBl) adresseLivraisonBl.value = '';
            }
            updateRecapBl();
        }

        if (zoneSelectBl) zoneSelectBl.addEventListener('change', onZoneChangeBl);

        if (lignesContainerBl) {
            lignesContainerBl.addEventListener('input', function(ev) {
                if (ev.target.classList.contains('ligne-qte') || ev.target.classList.contains('ligne-prix') || ev.target.classList.contains('ligne-prix-promo')) {
                    updateRecapBl();
                }
            });
        }

        if (formBl) {
            formBl.addEventListener('submit', function(ev) {
                if (zoneSelectBl && zoneSelectBl.value === 'custom' && adresseTaBl) {
                    if (adresseLivraisonBl) adresseLivraisonBl.value = adresseTaBl.value.trim();
                } else if (zoneSelectBl && zoneSelectBl.value && zoneSelectBl.value !== 'custom') {
                    onZoneChangeBl();
                }
                if (adresseLivraisonBl && !adresseLivraisonBl.value.trim()) {
                    ev.preventDefault();
                    alert('Veuillez sélectionner une adresse de livraison ou saisir une adresse personnalisée.');
                    return false;
                }
            });
        }

        var searchTimeoutBl;
        if (searchInputBl && searchResultsBl) {
            searchInputBl.addEventListener('input', function() {
                clearTimeout(searchTimeoutBl);
                var q = searchInputBl.value.trim();
                searchTimeoutBl = setTimeout(function() { doSearchBl(q); }, 250);
            });
            searchInputBl.addEventListener('focus', function() {
                var q = searchInputBl.value.trim();
                if (searchResultsBl.getAttribute('aria-hidden') === 'true' || searchResultsBl.innerHTML === '') {
                    doSearchBl(q);
                }
            });
            searchInputBl.addEventListener('blur', function() {
                setTimeout(function() {
                    if (!searchResultsBl.contains(document.activeElement)) {
                        searchResultsBl.innerHTML = '';
                        searchResultsBl.setAttribute('aria-hidden', 'true');
                    }
                }, 150);
            });
            searchResultsBl.addEventListener('mousedown', function(ev) { ev.preventDefault(); });
        }

        var searchClientInputBl = document.getElementById('search-client-bl');
        var searchClientResultsBl = document.getElementById('search-client-results-bl');
        var searchClientLoadingBl = document.getElementById('search-client-loading-bl');
        var clientNomInputBl = document.getElementById('client_nom_bl');
        var clientPrenomInputBl = document.getElementById('client_prenom_bl');
        var clientTelInputBl = document.getElementById('client_telephone_bl');
        var clientEmailInputBl = document.getElementById('client_email_bl');
        var userIdInputBl = document.getElementById('user_id_bl');
        var clientSearchTimeoutBl;
        if (searchClientInputBl && searchClientResultsBl && clientNomInputBl && clientPrenomInputBl && clientTelInputBl) {
            function doClientSearchBl(q) {
                if (q.length < 1) {
                    searchClientResultsBl.innerHTML = '';
                    searchClientResultsBl.setAttribute('aria-hidden', 'true');
                    return;
                }
                if (searchClientLoadingBl) searchClientLoadingBl.style.visibility = 'visible';
                fetch('ajax_search_clients.php?q=' + encodeURIComponent(q) + '&limit=15')
                    .then(function(r) { return r.json(); })
                    .then(function(data) {
                        searchClientResultsBl.innerHTML = '';
                        if (data.length === 0) {
                            searchClientResultsBl.innerHTML = '<div class="search-no-results">Aucun client trouvé.</div>';
                        } else {
                            data.forEach(function(c) {
                                var el = document.createElement('div');
                                el.className = 'search-result-item';
                                el.setAttribute('role', 'option');
                                el.innerHTML = '<span class="sr-nom">' + escapeHtml(c.nom_complet) + '</span>' +
                                    '<span class="sr-meta">' + escapeHtml(c.telephone) + (c.email ? ' &bull; ' + escapeHtml(c.email) : '') + '</span>';
                                el.addEventListener('mousedown', function(ev) {
                                    ev.preventDefault();
                                    clientNomInputBl.value = c.nom || '';
                                    clientPrenomInputBl.value = c.prenom || '';
                                    clientTelInputBl.value = c.telephone || '';
                                    if (clientEmailInputBl) clientEmailInputBl.value = c.email || '';
                                    if (userIdInputBl) userIdInputBl.value = (c.source === 'user') ? c.id : '';
                                    searchClientInputBl.value = '';
                                    searchClientResultsBl.innerHTML = '';
                                    searchClientResultsBl.setAttribute('aria-hidden', 'true');
                                });
                                searchClientResultsBl.appendChild(el);
                            });
                        }
                        searchClientResultsBl.setAttribute('aria-hidden', 'false');
                    })
                    .catch(function() {
                        searchClientResultsBl.innerHTML = '<div class="search-no-results">Erreur de recherche.</div>';
                    })
                    .finally(function() {
                        if (searchClientLoadingBl) searchClientLoadingBl.style.visibility = 'hidden';
                    });
            }
            searchClientInputBl.addEventListener('input', function() {
                clearTimeout(clientSearchTimeoutBl);
                var q = searchClientInputBl.value.trim();
                clientSearchTimeoutBl = setTimeout(function() { doClientSearchBl(q); }, 300);
            });
            searchClientInputBl.addEventListener('focus', function() {
                var q = searchClientInputBl.value.trim();
                if (q.length >= 1) doClientSearchBl(q);
            });
            searchClientInputBl.addEventListener('blur', function() {
                setTimeout(function() {
                    if (!searchClientResultsBl.contains(document.activeElement)) {
                        searchClientResultsBl.innerHTML = '';
                        searchClientResultsBl.setAttribute('aria-hidden', 'true');
                    }
                }, 150);
            });
            searchClientResultsBl.addEventListener('mousedown', function(ev) { ev.preventDefault(); });
        }

        updateLignesUIBl();
        if (modalBl && modalBl.classList.contains('modal-open') && zoneSelectBl && zoneSelectBl.value) {
            onZoneChangeBl();
        }
        updateRecapBl();
    })();
    </script>
</body>
</html>
