<?php
require_once __DIR__ . '/../../includes/session_admin.php';
/**
 * Recherche produits en stock pour commande manuelle (retourne JSON)
 */
session_start_persistent();
header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['admin_id'])) {
    echo json_encode(['error' => 'Non autorisé', 'items' => []]);
    exit;
}

require_once __DIR__ . '/../../includes/admin_route_access.php';
admin_route_enforce_json_empty();

$recherche = isset($_GET['q']) ? trim($_GET['q']) : '';
$limit = min(50, max(5, (int) ($_GET['limit'] ?? 30)));

require_once __DIR__ . '/../../models/model_produits.php';
$items = search_produits_en_stock_commande_manuelle($recherche, $limit, admin_vendeur_filter_id());

echo json_encode(['items' => $items]);
