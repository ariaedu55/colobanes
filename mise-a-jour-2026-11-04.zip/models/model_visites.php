<?php
/**
 * Modèle pour la gestion des produits visités
 * Programmation procédurale uniquement
 */

// Inclusion du fichier de connexion à la BDD
require_once __DIR__ . '/../conn/conn.php';

/**
 * Enregistre une visite d'un produit
 * @param int $user_id L'ID de l'utilisateur
 * @param int $produit_id L'ID du produit
 * @return bool True en cas de succès, False sinon
 */
function add_visite($user_id, $produit_id) {
    global $db;
    
    try {
        $stmt = $db->prepare("
            INSERT INTO produits_visites (user_id, produit_id, date_visite) 
            VALUES (:user_id, :produit_id, NOW())
            ON DUPLICATE KEY UPDATE date_visite = NOW()
        ");
        
        return $stmt->execute([
            'user_id' => $user_id,
            'produit_id' => $produit_id
        ]);
    } catch (PDOException $e) {
        return false;
    }
}

/**
 * Récupère les produits visités par un utilisateur
 * @param int $user_id L'ID de l'utilisateur
 * @param int $limit Nombre maximum de résultats (par défaut 20)
 * @return array|false Tableau des produits visités ou False en cas d'erreur
 */
function get_produits_visites_by_user($user_id, $limit = 20) {
    global $db;
    
    try {
        require_once __DIR__ . '/model_produits.php';
        $vj = produits_sql_vendeur_fragment();
        $stmt = $db->prepare("
            SELECT pv.*, p.*, c.nom as categorie_nom
            " . $vj['select'] . "
            FROM produits_visites pv
            INNER JOIN produits p ON pv.produit_id = p.id
            LEFT JOIN categories c ON p.categorie_id = c.id
            " . $vj['join'] . "
            WHERE pv.user_id = :user_id
            ORDER BY pv.date_visite DESC
            LIMIT :limit
        ");
        
        $stmt->bindValue(':user_id', $user_id, PDO::PARAM_INT);
        $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
        $stmt->execute();
        
        $visites = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        return $visites ? $visites : [];
    } catch (PDOException $e) {
        return false;
    }
}

/**
 * Compte le nombre de produits visités par un utilisateur
 * @param int $user_id L'ID de l'utilisateur
 * @return int Le nombre de produits visités
 */
function count_visites_by_user($user_id) {
    global $db;
    
    try {
        $stmt = $db->prepare("SELECT COUNT(DISTINCT produit_id) FROM produits_visites WHERE user_id = :user_id");
        $stmt->execute(['user_id' => $user_id]);
        return (int) $stmt->fetchColumn();
    } catch (PDOException $e) {
        return 0;
    }
}

/**
 * Récupère les produits les plus visités
 * @param int $limit Nombre minimum de produits requis (par défaut 10)
 * @return array Tableau des produits les plus visités ou tous les produits mélangés si moins de $limit
 */
function get_produits_plus_visites($limit = 10, $boutique_admin_id = null) {
    global $db;
    
    try {
        require_once __DIR__ . '/model_produits.php';
        $extra = '';
        if ($boutique_admin_id !== null && $boutique_admin_id !== '' && produits_has_column('admin_id')) {
            $extra = ' AND p.admin_id = :boutique_admin_id';
        }
        $extra .= produits_region_sql_with_alias($boutique_admin_id)['sql'];
        // Récupérer les produits les plus visités avec le nombre de visites
        $vj = produits_sql_vendeur_fragment();
        $stmt = $db->prepare("
            SELECT 
                p.*,
                c.nom as categorie_nom,
                MAX(vend.boutique_nom) AS vendeur_boutique_nom,
                MAX(vend.boutique_slug) AS vendeur_boutique_slug,
                COUNT(pv.id) as nb_visites
            FROM produits p
            LEFT JOIN categories c ON p.categorie_id = c.id
            " . $vj['join'] . "
            LEFT JOIN produits_visites pv ON p.id = pv.produit_id
            WHERE p.statut IN ('actif', 'rupture_stock') $extra
            GROUP BY p.id
            HAVING nb_visites > 0
            ORDER BY nb_visites DESC, p.date_creation DESC
            LIMIT :limit
        ");
        if ($boutique_admin_id !== null && $boutique_admin_id !== '' && produits_has_column('admin_id')) {
            $stmt->bindValue(':boutique_admin_id', (int) $boutique_admin_id, PDO::PARAM_INT);
        }
        produits_bind_region_stmt($stmt, $boutique_admin_id);
        
        $stmt->bindValue(':limit', $limit * 2, PDO::PARAM_INT); // Récupérer plus pour avoir de la variété
        $stmt->execute();
        $produits = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        // Si moins de $limit produits visités, récupérer tous les produits actifs
        if (count($produits) < $limit) {
            if (file_exists(__DIR__ . '/model_produits.php')) {
                require_once __DIR__ . '/model_produits.php';
                $tous_produits = get_all_produits_paginated(0, max($limit * 3, 30), $boutique_admin_id);
                
                if ($tous_produits !== false && !empty($tous_produits)) {
                    // Mélanger aléatoirement
                    mt_srand(time() + (int)(microtime(true) * 1000000));
                    shuffle($tous_produits);
                    // Limiter au nombre demandé
                    $produits = array_slice($tous_produits, 0, $limit);
                }
            }
        } else {
            // Mélanger aléatoirement les produits les plus visités
            mt_srand(time() + (int)(microtime(true) * 1000000));
            shuffle($produits);
            // Limiter au nombre demandé
            $produits = array_slice($produits, 0, $limit);
        }
        
        return $produits ? $produits : [];
    } catch (PDOException $e) {
        // En cas d'erreur, retourner tous les produits actifs mélangés
        if (file_exists(__DIR__ . '/model_produits.php')) {
            require_once __DIR__ . '/model_produits.php';
            $produits = get_all_produits('actif');
            if ($produits !== false && !empty($produits)) {
                mt_srand(time() + (int)(microtime(true) * 1000000));
                shuffle($produits);
                $produits = array_slice($produits, 0, $limit);
                return $produits;
            }
        }
        return [];
    }
}

/**
 * Classement « Les plus consultés » (page plus-consultes.php) : produits triés par nombre de visites,
 * sans mélange, avec le filtre de région du visiteur.
 *
 * @return array<int, array> chaque ligne contient nb_visites
 */
function get_produits_classement_visites(int $limit = 70): array
{
    global $db;
    require_once __DIR__ . '/model_produits.php';
    $limit = max(1, min(200, $limit));
    try {
        $vj = produits_sql_vendeur_fragment();
        $rj = produits_sql_rayon_categorie_nom_fragment();
        $region_sql = produits_region_sql_with_alias(null)['sql'];
        $stmt = $db->prepare("
            SELECT p.*, " . $rj['categorie_nom_sql'] . " AS categorie_nom, v.nb AS nb_visites
            " . $vj['select'] . "
            FROM produits p
            INNER JOIN (
                SELECT produit_id, COUNT(*) AS nb FROM produits_visites GROUP BY produit_id
            ) v ON v.produit_id = p.id
            LEFT JOIN categories c ON p.categorie_id = c.id
            " . $rj['join'] . "
            " . $vj['join'] . "
            WHERE p.statut IN ('actif', 'rupture_stock') $region_sql
            ORDER BY v.nb DESC, p.date_creation DESC, p.id DESC
            LIMIT " . (int) $limit);
        produits_bind_region_stmt($stmt, null);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    } catch (PDOException $e) {
        error_log('[get_produits_classement_visites] ' . $e->getMessage());
        return [];
    }
}

?>
